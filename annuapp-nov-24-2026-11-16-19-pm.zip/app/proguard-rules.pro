# Keep WebView JS bridge / Android service entrypoints intact
-keepattributes *Annotation*
-keep class com.annu.companion.AnnuVoiceInteractionService { *; }
-keep class com.annu.companion.AnnuVoiceInteractionSessionService { *; }
-keep class com.annu.companion.FloatingService { *; }
-keep class com.annu.companion.WakeWordService { *; }
-keep class com.annu.companion.CallAlertReceiver { *; }
-keep class com.annu.companion.ReminderReceiver { *; }
