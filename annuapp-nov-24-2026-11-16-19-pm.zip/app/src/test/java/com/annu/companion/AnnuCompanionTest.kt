package com.annu.companion

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.test.core.app.ApplicationProvider
import com.annu.companion.brain.CommandProcessor
import com.annu.companion.brain.CommandResult
import com.annu.companion.brain.SensitiveAction
import com.annu.companion.data.AnnuMemoryRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class AnnuCompanionTest {

    private lateinit var context: Context
    private lateinit var memory: AnnuMemoryRepository
    private lateinit var processor: CommandProcessor

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("annu", Context.MODE_PRIVATE).edit().clear().commit()
        memory = AnnuMemoryRepository(context)
        processor = CommandProcessor(context, memory)
    }

    @Test
    fun `legacy user_note migrates cleanly into structured notes`() {
        context.getSharedPreferences("annu", Context.MODE_PRIVATE)
            .edit().putString("user_note", "Drink warm water").commit()
        val repo = AnnuMemoryRepository(context)
        val notes = repo.getNotes()
        assertEquals(1, notes.size)
        assertEquals("Drink warm water", notes.first().content)
    }

    @Test
    fun `hinglish note and reminder commands persist locally`() {
        val noteRes = processor.process("Remember that my keys are on the desk")
        assertTrue(noteRes is CommandResult.Reply)
        assertEquals(1, memory.getNotes().size)
        assertEquals("my keys are on the desk", memory.getNotes().first().content)

        val remRes = processor.process("Remind me in 25 minutes to take medicine")
        assertTrue(remRes is CommandResult.Reply)
        assertEquals(1, memory.getReminders().size)
        assertEquals("take medicine", memory.getReminders().first().title)
    }

    @Test
    fun `sensitive actions require confirmation before execution`() {
        memory.addNote("Important note")

        val deleteRes = processor.process("Delete all notes")
        assertTrue(deleteRes is CommandResult.NeedsConfirmation)
        assertEquals(1, memory.getNotes().size)

        val confirmRes = processor.executeSensitiveAction(SensitiveAction.DeleteAllNotes)
        assertTrue(confirmRes.text.contains("delete", ignoreCase = true))
        assertEquals(0, memory.getNotes().size)

        val callRes = processor.process("Call 9876543210")
        assertTrue(callRes is CommandResult.NeedsConfirmation)
        val dialRes = processor.executeSensitiveAction((callRes as CommandResult.NeedsConfirmation).action)
        assertEquals(Intent.ACTION_DIAL, dialRes.launchIntent?.action)

        val smsRes = processor.process("Send message to Mom")
        assertTrue(smsRes is CommandResult.NeedsConfirmation)
    }

    @Test
    fun `device commands and gestures route properly`() {
        val wifi = processor.process("Wi-Fi settings kholo") as CommandResult.Reply
        assertEquals(Settings.ACTION_WIFI_SETTINGS, wifi.launchIntent?.action)

        val dance = processor.process("Dance karo") as CommandResult.Reply
        assertEquals("dance", dance.animation)

        val floatOn = processor.process("Float on karo") as CommandResult.Reply
        assertEquals("START", floatOn.floatingAction)

        val floatSmall = processor.process("Chota ho ja") as CommandResult.Reply
        assertEquals("SIZE_SMALL", floatSmall.floatingAction)

        val wakeOn = processor.process("Hey ANNU wake listening start") as CommandResult.Reply
        assertEquals(com.annu.companion.brain.AppCommandAction.START_WAKE, wakeOn.appAction)

        val langEn = processor.process("Speak English") as CommandResult.Reply
        assertEquals(com.annu.companion.data.SpeechLanguageMode.ENGLISH, langEn.switchLanguage)

        val openEnded = processor.process("Explain photosynthesis simply")
        assertTrue(openEnded is CommandResult.AskAiBrain)
    }

    @Test
    fun `bundled vrm and offline threejs assets resolve via WebViewAssetLoader`() {
        val loader = AnnuWebAssets.create(context)
        val urls = listOf(
            "https://appassets.androidplatform.net/assets/annu.html",
            "https://appassets.androidplatform.net/assets/annu.vrm",
            "https://appassets.androidplatform.net/assets/vendor/three.module.js",
            "https://appassets.androidplatform.net/assets/vendor/three.core.js",
            "https://appassets.androidplatform.net/assets/vendor/loaders/GLTFLoader.js",
            "https://appassets.androidplatform.net/assets/vendor/utils/BufferGeometryUtils.js",
            "https://appassets.androidplatform.net/assets/vendor/three-vrm.module.min.js"
        )
        urls.forEach { url ->
            val resp = loader.shouldInterceptRequest(Uri.parse(url))
            assertNotNull("Missing bundled asset for $url", resp)
            resp?.data?.close()
        }
    }
}
