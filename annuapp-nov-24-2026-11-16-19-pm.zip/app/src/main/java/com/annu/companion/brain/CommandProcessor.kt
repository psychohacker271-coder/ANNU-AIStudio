package com.annu.companion.brain

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.annu.companion.ReminderReceiver
import com.annu.companion.data.AnnuMemoryRepository
import com.annu.companion.data.SpeechLanguageMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

enum class ResponseSource(val badge: String) {
    OFFLINE_ENGINE("Offline Command Engine"),
    OLLAMA_AI("Local Ollama AI")
}

sealed class SensitiveAction {
    data object DeleteAllNotes : SensitiveAction()
    data object DeleteAllReminders : SensitiveAction()
    data class DialNumberOrContact(val target: String) : SensitiveAction()
    data class SendMessage(val target: String, val messageBody: String) : SensitiveAction()
}

enum class AppCommandAction {
    START_WAKE,
    STOP_WAKE,
    REQUEST_ASSISTANT_ROLE,
    PICK_VRM,
    PICK_AUDIO,
    PLAY_AUDIO,
    STOP_AUDIO,
    ENABLE_CALL_ALERTS,
    OPEN_ANNU_SETTINGS
}

sealed class CommandResult {
    data class Reply(
        val text: String,
        val source: ResponseSource = ResponseSource.OFFLINE_ENGINE,
        val animation: String? = null,
        val launchIntent: Intent? = null,
        val floatingAction: String? = null,
        val appAction: AppCommandAction? = null,
        val switchLanguage: SpeechLanguageMode? = null
    ) : CommandResult()

    data class NeedsConfirmation(
        val promptText: String,
        val confirmLabel: String,
        val action: SensitiveAction
    ) : CommandResult()

    data object AskAiBrain : CommandResult()
}

class CommandProcessor(
    private val context: Context,
    private val memory: AnnuMemoryRepository
) {
    fun process(rawInput: String): CommandResult {
        val original = rawInput.trim()
        val lower = original.lowercase(Locale.ROOT)
        if (lower.isEmpty()) {
            return CommandResult.Reply("Boss, kuch boliye ya likhiye, main sun rahi hoon.")
        }

        // Sensitive actions ALWAYS require explicit confirmation first
        if ((lower.contains("delete") || lower.contains("clear") || lower.contains("hatao") || lower.contains("mita")) &&
            (lower.contains("note") || lower.contains("memory") || lower.contains("sab yaad"))
        ) {
            return CommandResult.NeedsConfirmation(
                promptText = "Boss, kya aap sach mein saare saved notes delete karna chahte hain? Confirm karein.",
                confirmLabel = "Delete All Notes",
                action = SensitiveAction.DeleteAllNotes
            )
        }

        if ((lower.contains("delete") || lower.contains("clear") || lower.contains("hatao")) &&
            lower.contains("reminder")
        ) {
            return CommandResult.NeedsConfirmation(
                promptText = "Boss, kya main saare reminders delete kar doon? Please confirm karein.",
                confirmLabel = "Delete Reminders",
                action = SensitiveAction.DeleteAllReminders
            )
        }

        if (lower.startsWith("call ") || lower.contains("call karo") || lower.contains("phone lagao") || lower.startsWith("dial ")) {
            val target = original
                .replace(Regex("(?i)^(call|dial)\\s+"), "")
                .replace(Regex("(?i)\\s*(ko\\s*)?(call karo|phone lagao)$"), "")
                .trim()
                .ifEmpty { "Phone Dialer" }
            return CommandResult.NeedsConfirmation(
                promptText = "Boss, '$target' ke liye phone dialer kholne se pehle confirm karein.",
                confirmLabel = "Open Dialer",
                action = SensitiveAction.DialNumberOrContact(target)
            )
        }

        if (lower.contains("send message") || lower.contains("send sms") || lower.contains("message bhejo") || lower.contains("whatsapp message")) {
            return CommandResult.NeedsConfirmation(
                promptText = "Boss, message bhejna ek sensitive action hai. Confirm karein toh main SMS composer khol doon.",
                confirmLabel = "Open Messages",
                action = SensitiveAction.SendMessage(target = "", messageBody = original)
            )
        }

        // Voice-controlled App & Companion Actions (no extra buttons needed!)
        if (lower.contains("annu settings") || lower.contains("app settings") || lower.contains("ollama") || lower.contains("permissions")) {
            return CommandResult.Reply(
                text = "Ji Boss, ANNU settings khol rahi hoon.",
                animation = "nod",
                appAction = AppCommandAction.OPEN_ANNU_SETTINGS
            )
        }

        if (lower.contains("default assistant") || lower.contains("assistant banao") || lower.contains("set assistant")) {
            return CommandResult.Reply(
                text = "Ji Boss, ANNU ko default assistant set karne ka prompt khol rahi hoon.",
                animation = "happy",
                appAction = AppCommandAction.REQUEST_ASSISTANT_ROLE
            )
        }

        if ((lower.contains("wake") || lower.contains("hey annu")) &&
            (lower.contains("stop") || lower.contains("off") || lower.contains("band"))
        ) {
            return CommandResult.Reply(
                text = "Ji Boss, Hey ANNU wake listening band kar rahi hoon.",
                animation = "nod",
                appAction = AppCommandAction.STOP_WAKE
            )
        }
        if ((lower.contains("wake") || lower.contains("hey annu")) &&
            (lower.contains("start") || lower.contains("on") || lower.contains("enable") || lower.contains("chalu"))
        ) {
            return CommandResult.Reply(
                text = "Ji Boss, Hey ANNU wake listening shuru kar rahi hoon.",
                animation = "nod",
                appAction = AppCommandAction.START_WAKE
            )
        }

        if (lower.contains("call alert") && (lower.contains("enable") || lower.contains("on") || lower.contains("chalu"))) {
            return CommandResult.Reply(
                text = "Ji Boss, incoming call alerts ke liye permission check kar rahi hoon.",
                animation = "nod",
                appAction = AppCommandAction.ENABLE_CALL_ALERTS
            )
        }

        if ((lower.contains("vrm") || lower.contains("character") || lower.contains("model")) &&
            (lower.contains("import") || lower.contains("change") || lower.contains("replace") || lower.contains("badlo"))
        ) {
            return CommandResult.Reply(
                text = "Ji Boss, naya VRM model choose karne ke liye file picker khol rahi hoon.",
                animation = "happy",
                appAction = AppCommandAction.PICK_VRM
            )
        }

        if (lower.contains("import audio") || lower.contains("audio import") || lower.contains("audio daalo")) {
            return CommandResult.Reply(
                text = "Ji Boss, audio sample import karne ke liye picker khol rahi hoon.",
                animation = "nod",
                appAction = AppCommandAction.PICK_AUDIO
            )
        }
        if (lower.contains("stop audio") || lower.contains("audio band")) {
            return CommandResult.Reply(
                text = "Audio sample band kar diya Boss.",
                animation = "nod",
                appAction = AppCommandAction.STOP_AUDIO
            )
        }
        if (lower.contains("play audio") || lower.contains("voice sample") || lower.contains("audio chala") || lower.contains("audio sun")) {
            return CommandResult.Reply(
                text = "Audio sample check kar rahi hoon Boss.",
                appAction = AppCommandAction.PLAY_AUDIO
            )
        }

        // Language switching by voice
        if (lower.contains("speak hindi") || lower.contains("hindi mein") || lower.contains("hindi mode") || lower.contains("language hindi")) {
            return CommandResult.Reply(
                text = "Ji Boss, ab main Hindi mein baat karungi.",
                animation = "nod",
                switchLanguage = SpeechLanguageMode.HINDI
            )
        }
        if (lower.contains("speak english") || lower.contains("english mein") || lower.contains("english mode") || lower.contains("language english")) {
            return CommandResult.Reply(
                text = "Sure Boss, switching my voice to Indian English.",
                animation = "nod",
                switchLanguage = SpeechLanguageMode.ENGLISH
            )
        }
        if (lower.contains("hinglish")) {
            return CommandResult.Reply(
                text = "Done Boss! Ab Hinglish mode active hai.",
                animation = "happy",
                switchLanguage = SpeechLanguageMode.HINGLISH
            )
        }

        // Floating overlay controls by voice
        if (lower.contains("stop floating") || lower.contains("float off") || lower.contains("band ho ja")) {
            return CommandResult.Reply("Theek hai Boss, floating overlay band kar rahi hoon.", floatingAction = "STOP")
        }
        if (lower.contains("float") || lower.contains("screen par aa")) {
            if (lower.contains("small") || lower.contains("chota") || lower.contains("chhota")) {
                return CommandResult.Reply("Floating ANNU ko chhota kar diya Boss.", floatingAction = "SIZE_SMALL")
            }
            if (lower.contains("large") || lower.contains("big") || lower.contains("bada")) {
                return CommandResult.Reply("Floating ANNU ko bada kar diya Boss.", floatingAction = "SIZE_LARGE")
            }
            if (lower.contains("reset")) {
                return CommandResult.Reply("Floating ANNU ki size aur position reset kar di Boss.", floatingAction = "SIZE_RESET")
            }
            return CommandResult.Reply("Floating companion start kar rahi hoon Boss.", floatingAction = "START")
        }
        if (lower.contains("chota ho ja") || lower.contains("make smaller")) {
            return CommandResult.Reply("Floating size chhota kar rahi hoon Boss.", floatingAction = "SIZE_SMALL")
        }
        if (lower.contains("bada ho ja") || lower.contains("make larger")) {
            return CommandResult.Reply("Floating size bada kar rahi hoon Boss.", floatingAction = "SIZE_LARGE")
        }

        // System Settings
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            return CommandResult.Reply(
                text = "Ji Boss, Wi-Fi settings khol rahi hoon.",
                animation = "nod",
                launchIntent = Intent(Settings.ACTION_WIFI_SETTINGS)
            )
        }
        if (lower.contains("bluetooth")) {
            return CommandResult.Reply(
                text = "Ji Boss, Bluetooth settings khol rahi hoon.",
                animation = "nod",
                launchIntent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            )
        }
        if (lower.contains("settings") || lower.contains("सेटिंग")) {
            return CommandResult.Reply(
                text = "Boss, phone settings khol rahi hoon.",
                animation = "nod",
                launchIntent = Intent(Settings.ACTION_SETTINGS)
            )
        }

        // Camera & Maps
        if (lower.contains("camera") || lower.contains("कैमरा") || lower.contains("photo khicho")) {
            return CommandResult.Reply(
                text = "Camera khol rahi hoon Boss!",
                animation = "happy",
                launchIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            )
        }
        if (lower.contains("maps") || lower.contains("map") || lower.contains("नक्शा") || lower.contains("rasta")) {
            val query = original
                .replace(Regex("(?i).*?(maps|map|for|search)\\s+"), "")
                .takeIf { it.isNotBlank() && !it.equals(original, ignoreCase = true) }
                ?: ""
            val uri = Uri.parse("geo:0,0?q=" + Uri.encode(query))
            return CommandResult.Reply(
                text = if (query.isEmpty()) "Maps khol rahi hoon Boss." else "Maps mein '$query' search kar rahi hoon.",
                animation = "nod",
                launchIntent = Intent(Intent.ACTION_VIEW, uri)
            )
        }

        // Known apps
        if (lower.contains("youtube")) {
            return openPackageOrExplain("com.google.android.youtube", "YouTube")
        }
        if (lower.contains("chrome")) {
            return openPackageOrExplain("com.android.chrome", "Chrome")
        }

        // Dynamic installed app opener ("open <app>" / "<app> kholo")
        if (lower.startsWith("open ") || lower.endsWith(" kholo") || lower.endsWith(" open karo")) {
            val appQuery = lower
                .removePrefix("open ")
                .removeSuffix(" kholo")
                .removeSuffix(" open karo")
                .trim()
            if (appQuery.isNotEmpty()) {
                val launch = findInstalledAppIntent(appQuery)
                if (launch != null) {
                    return CommandResult.Reply(
                        text = "Ji Boss, ${launch.first} khol rahi hoon.",
                        animation = "happy",
                        launchIntent = launch.second
                    )
                }
            }
        }

        // Time, Date, Battery
        if (lower.contains("time") || lower.contains("समय") || lower.contains("kitne baje")) {
            val now = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            return CommandResult.Reply("Boss, abhi $now ho rahe hain.", animation = "nod")
        }
        if (lower.contains("date") || lower.contains("tarikh") || lower.contains("तारीख") || lower.contains("aaj ka din")) {
            val today = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            return CommandResult.Reply("Boss, aaj $today hai.", animation = "nod")
        }
        if (lower.contains("battery") || lower.contains("बैटरी") || lower.contains("charge")) {
            return CommandResult.Reply(readBatteryStatus(), animation = "nod")
        }

        // Reminders & Alarm
        if (lower.contains("remind me") || lower.contains("yaad dila") || lower.contains("reminder")) {
            if (lower.contains("show") || lower.contains("list") || lower.contains("batao") || lower.contains("kya reminder")) {
                val active = memory.getReminders().filter { !it.completed }
                return if (active.isEmpty()) {
                    CommandResult.Reply("Boss, abhi koi pending reminder nahi hai.", animation = "idle")
                } else {
                    val fmt = SimpleDateFormat("h:mm a, d MMM", Locale.getDefault())
                    val text = active.take(4).joinToString("\n• ", prefix = "Boss, aapke active reminders:\n• ") {
                        "${it.title} (${fmt.format(Date(it.triggerAtMillis))})"
                    }
                    CommandResult.Reply(text, animation = "nod")
                }
            }
            val parsed = parseReminder(original)
            if (parsed != null) {
                val (minutes, title) = parsed
                val triggerAt = System.currentTimeMillis() + minutes * 60_000L
                val item = memory.addReminder(title, triggerAt)
                ReminderReceiver.schedule(context, item.id, item.title, triggerAt)
                return CommandResult.Reply(
                    text = "Ji Boss, maine $minutes minute baad ka reminder save kar diya: \"$title\".",
                    animation = "happy"
                )
            }
        }

        if (lower.contains("alarm") || lower.contains("timer")) {
            return CommandResult.Reply(
                text = "Boss, alarm app khol rahi hoon.",
                animation = "nod",
                launchIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS)
            )
        }

        // Notes / Local Memory
        if (lower.startsWith("remember ") || lower.startsWith("note ") || lower.contains("note save") || lower.contains("yaad rakh")) {
            val noteText = original
                .replace(Regex("(?i)^(remember that|remember|note down|note|save note|yaad rakhna|yaad rakho)[:\\s-]*"), "")
                .trim()
            if (noteText.isNotEmpty()) {
                memory.addNote(noteText)
                return CommandResult.Reply("Ji Boss, maine yeh local memory mein save kar liya: \"$noteText\".", animation = "happy")
            }
        }
        if (lower.contains("kya yaad") || lower.contains("what do you remember") || lower.contains("mera note") || lower.contains("my notes") || lower.contains("note bata")) {
            val notes = memory.getNotes()
            return if (notes.isEmpty()) {
                CommandResult.Reply("Boss, abhi koi private note save nahi hai.", animation = "idle")
            } else {
                val summary = notes.take(5).joinToString("\n• ", prefix = "Boss, aapke saved notes:\n• ") { it.content }
                CommandResult.Reply(summary, animation = "nod")
            }
        }

        // 3D companion gestures
        if (lower.contains("dance") || lower.contains("naach")) return CommandResult.Reply("Ji Boss, dance mode on!", animation = "dance")
        if (lower.contains("walk") || lower.contains("चल") || lower.contains("chalo")) return CommandResult.Reply("Boss, walking animation shuru!", animation = "walk")
        if (lower.contains("sit") || lower.contains("बैठ") || lower.contains("baith")) return CommandResult.Reply("Ji Boss, sitting pose!", animation = "sit")
        if (lower.contains("nod") || lower.contains("सिर हिला")) return CommandResult.Reply("Ji Boss!", animation = "nod")
        if (lower.contains("think") || lower.contains("सोच") || lower.contains("soch")) return CommandResult.Reply("Hmm Boss, soch rahi hoon.", animation = "think")
        if (lower.contains("happy") || lower.contains("खुश") || lower.contains("khush")) return CommandResult.Reply("Yay Boss! Bahut khush hoon.", animation = "happy")
        if (lower.contains("wave") || lower.contains("haath hila") || lower.contains("bye")) return CommandResult.Reply("Hello Boss!", animation = "wave")
        if (lower.contains("so ja") || lower.contains("sleep") || lower.contains("good night")) return CommandResult.Reply("Good night Boss, main aaram kar rahi hoon.", animation = "sleep")
        if (lower.contains("wake") || lower.contains("uth ja") || lower.contains("jaag") || lower.contains("good morning")) return CommandResult.Reply("Good morning Boss! Main jaag gayi aur ready hoon.", animation = "wake")

        // Honest conversational offline small-talk
        if (lower.matches(Regex(".*\\b(hi|hello|hey|namaste|namaskar|annu)\\b.*")) || lower.contains("नमस्ते")) {
            return CommandResult.Reply(
                text = "Ji Boss! Namaste. Main ANNU hoon — bas boliye kya karna hai?",
                animation = "wave"
            )
        }
        if (lower.contains("who are you") || lower.contains("tum kaun") || lower.contains("aap kaun")) {
            return CommandResult.Reply(
                text = "Main ANNU hoon, aapki Android 3D assistant. Abhi main offline command engine par chal rahi hoon; generative AI chat ke liye Settings mein free local Ollama connect kar sakte hain.",
                animation = "happy"
            )
        }
        if (lower.contains("how are you") || lower.contains("kaisi ho") || lower.contains("kaise ho")) {
            return CommandResult.Reply(
                text = "Main bilkul theek hoon Boss! Aap kaise hain? Koi bhi command ya baat boliye.",
                animation = "happy"
            )
        }
        if (lower.contains("thank") || lower.contains("shukriya") || lower.contains("dhanyawad")) {
            return CommandResult.Reply(
                text = "Hamesha aapki help ke liye ready hoon Boss!",
                animation = "happy"
            )
        }

        // Otherwise ask local Ollama AI if configured
        return CommandResult.AskAiBrain
    }

    fun executeSensitiveAction(action: SensitiveAction): CommandResult.Reply {
        return when (action) {
            SensitiveAction.DeleteAllNotes -> {
                memory.clearAllNotes()
                CommandResult.Reply("Boss, saare saved notes delete kar diye gaye hain.", animation = "nod")
            }
            SensitiveAction.DeleteAllReminders -> {
                memory.getReminders().forEach { ReminderReceiver.cancel(context, it.id) }
                memory.clearAllReminders()
                CommandResult.Reply("Boss, saare local reminders delete kar diye hain.", animation = "nod")
            }
            is SensitiveAction.DialNumberOrContact -> {
                val digits = action.target.filter { it.isDigit() || it == '+' }
                val uri = if (digits.length >= 3) Uri.parse("tel:$digits") else Uri.parse("tel:")
                CommandResult.Reply(
                    text = "Phone dialer khol rahi hoon Boss. Call aap khud place kar sakte hain.",
                    animation = "nod",
                    launchIntent = Intent(Intent.ACTION_DIAL, uri)
                )
            }
            is SensitiveAction.SendMessage -> {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).apply {
                    putExtra("sms_body", action.messageBody)
                }
                CommandResult.Reply(
                    text = "SMS app khol rahi hoon Boss. Bhejne se pehle message check kar lein.",
                    animation = "nod",
                    launchIntent = intent
                )
            }
        }
    }

    private fun openPackageOrExplain(pkg: String, label: String): CommandResult.Reply {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
        return if (intent != null) {
            CommandResult.Reply("$label khol rahi hoon Boss.", animation = "happy", launchIntent = intent)
        } else {
            CommandResult.Reply("Boss, $label is phone par installed nahi mila.", animation = "think")
        }
    }

    private fun findInstalledAppIntent(query: String): Pair<String, Intent>? {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        val match = apps.firstOrNull { info ->
            val label = info.loadLabel(pm).toString().lowercase(Locale.ROOT)
            label == query || label.contains(query)
        } ?: return null
        val pkg = match.activityInfo.packageName
        val launch = pm.getLaunchIntentForPackage(pkg) ?: return null
        return match.loadLabel(pm).toString() to launch
    }

    private fun readBatteryStatus(): String {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val battery = context.registerReceiver(null, filter)
            ?: return "Boss, battery status abhi read nahi ho paaya."
        val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        if (level < 0) return "Boss, battery status available nahi hai."
        val pct = (level * 100) / scale
        val stateLabel = if (charging) "aur phone charge ho raha hai" else "discharging"
        return "Boss, battery abhi $pct percent hai ($stateLabel)."
    }

    private fun parseReminder(input: String): Pair<Int, String>? {
        val p = Pattern.compile("(\\d+)\\s*(minutes|minute|min|hours|hour|hr|ghante|ghanta)", Pattern.CASE_INSENSITIVE)
        val m = p.matcher(input)
        val minutes = if (m.find()) {
            val value = m.group(1)?.toIntOrNull() ?: 10
            val unit = m.group(2)?.lowercase(Locale.ROOT).orEmpty()
            if (unit.startsWith("h") || unit.startsWith("g")) value * 60 else value
        } else {
            10
        }.coerceIn(1, 1440)

        val cleaned = input
            .replace(Regex("(?i)(remind me|set a reminder|reminder|yaad dilana|yaad dila)"), "")
            .replace(Regex("(?i)(in|after|baad)?\\s*\\d+\\s*(minutes|minute|min|hours|hour|hr|ghante|ghanta)"), "")
            .replace(Regex("(?i)^\\s*(to|ki|for|ka)\\s+"), "")
            .trim()
            .ifEmpty { "Check ANNU reminder" }

        return minutes to cleaned
    }
}
