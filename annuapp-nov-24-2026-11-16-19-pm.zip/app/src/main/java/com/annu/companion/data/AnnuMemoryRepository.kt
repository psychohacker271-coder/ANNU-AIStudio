package com.annu.companion.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class AnnuNote(
    val id: String,
    val content: String,
    val updatedAt: Long
)

data class AnnuReminder(
    val id: String,
    val title: String,
    val triggerAtMillis: Long,
    val completed: Boolean = false
)

enum class SpeechLanguageMode(val code: String, val label: String, val ttsLocaleTag: String) {
    HINGLISH("hinglish", "Hinglish (Auto)", "hi-IN"),
    HINDI("hi-IN", "Hindi (hi-IN)", "hi-IN"),
    ENGLISH("en-IN", "English (en-IN)", "en-IN");

    companion object {
        fun fromStored(value: String?): SpeechLanguageMode {
            return entries.firstOrNull { it.code == value } ?: HINGLISH
        }
    }
}

class AnnuMemoryRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences("annu", Context.MODE_PRIVATE)

    init {
        migrateLegacyNoteIfNeeded()
    }

    private fun migrateLegacyNoteIfNeeded() {
        val legacy = prefs.getString("user_note", "")?.trim().orEmpty()
        if (legacy.isNotEmpty() && !prefs.contains("notes_json")) {
            val initial = listOf(
                AnnuNote(
                    id = UUID.randomUUID().toString(),
                    content = legacy,
                    updatedAt = System.currentTimeMillis()
                )
            )
            saveNotes(initial)
        }
    }

    fun getNotes(): List<AnnuNote> {
        val raw = prefs.getString("notes_json", "[]") ?: "[]"
        val list = mutableListOf<AnnuNote>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val content = obj.optString("content", "").trim()
                if (content.isNotEmpty()) {
                    list.add(
                        AnnuNote(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            content = content,
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return list.sortedByDescending { it.updatedAt }
    }

    fun addNote(content: String): AnnuNote {
        val trimmed = content.trim()
        val note = AnnuNote(
            id = UUID.randomUUID().toString(),
            content = trimmed,
            updatedAt = System.currentTimeMillis()
        )
        val updated = listOf(note) + getNotes()
        saveNotes(updated)
        return note
    }

    fun deleteNote(id: String) {
        saveNotes(getNotes().filterNot { it.id == id })
    }

    fun clearAllNotes() {
        saveNotes(emptyList())
        prefs.edit().remove("user_note").apply()
    }

    private fun saveNotes(notes: List<AnnuNote>) {
        val arr = JSONArray()
        notes.forEach { n ->
            arr.put(
                JSONObject()
                    .put("id", n.id)
                    .put("content", n.content)
                    .put("updatedAt", n.updatedAt)
            )
        }
        prefs.edit()
            .putString("notes_json", arr.toString())
            .putString("user_note", notes.firstOrNull()?.content ?: "")
            .apply()
    }

    fun getReminders(): List<AnnuReminder> {
        val raw = prefs.getString("reminders_json", "[]") ?: "[]"
        val list = mutableListOf<AnnuReminder>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val title = obj.optString("title", "").trim()
                if (title.isNotEmpty()) {
                    list.add(
                        AnnuReminder(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            title = title,
                            triggerAtMillis = obj.optLong("triggerAtMillis", System.currentTimeMillis()),
                            completed = obj.optBoolean("completed", false)
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return list.sortedBy { it.triggerAtMillis }
    }

    fun addReminder(title: String, triggerAtMillis: Long): AnnuReminder {
        val reminder = AnnuReminder(
            id = UUID.randomUUID().toString(),
            title = title.trim(),
            triggerAtMillis = triggerAtMillis,
            completed = false
        )
        val updated = getReminders() + reminder
        saveReminders(updated)
        return reminder
    }

    fun markReminderCompleted(id: String, completed: Boolean) {
        saveReminders(getReminders().map { if (it.id == id) it.copy(completed = completed) else it })
    }

    fun deleteReminder(id: String) {
        saveReminders(getReminders().filterNot { it.id == id })
    }

    fun clearAllReminders() {
        saveReminders(emptyList())
    }

    private fun saveReminders(reminders: List<AnnuReminder>) {
        val arr = JSONArray()
        reminders.forEach { r ->
            arr.put(
                JSONObject()
                    .put("id", r.id)
                    .put("title", r.title)
                    .put("triggerAtMillis", r.triggerAtMillis)
                    .put("completed", r.completed)
            )
        }
        prefs.edit().putString("reminders_json", arr.toString()).apply()
    }

    fun buildLocalMemoryContext(): String {
        val notes = getNotes().take(5)
        val activeReminders = getReminders().filter { !it.completed }.take(5)
        if (notes.isEmpty() && activeReminders.isEmpty()) return ""
        val sb = StringBuilder()
        if (notes.isNotEmpty()) {
            sb.append("Saved Notes:\n")
            notes.forEach { sb.append("- ").append(it.content).append('\n') }
        }
        if (activeReminders.isNotEmpty()) {
            sb.append("Active Reminders:\n")
            activeReminders.forEach { sb.append("- ").append(it.title).append('\n') }
        }
        return sb.toString()
    }

    fun getLanguageMode(): SpeechLanguageMode =
        SpeechLanguageMode.fromStored(prefs.getString("speech_language", SpeechLanguageMode.HINGLISH.code))

    fun setLanguageMode(mode: SpeechLanguageMode) {
        prefs.edit().putString("speech_language", mode.code).apply()
    }

    fun getBrainUrl(): String = prefs.getString("brain_url", "")?.trim().orEmpty()
    fun getBrainModel(): String = prefs.getString("brain_model", "qwen3.5:0.8b")?.trim().orEmpty().ifEmpty { "qwen3.5:0.8b" }

    fun saveBrainConfig(url: String, model: String) {
        prefs.edit()
            .putString("brain_url", url.trim())
            .putString("brain_model", model.trim().ifEmpty { "qwen3.5:0.8b" })
            .apply()
    }

    fun isFloatingEnabled(): Boolean = prefs.getBoolean("floating_enabled", false)
    fun setFloatingEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("floating_enabled", enabled).apply()
    }

    fun isWakeEnabled(): Boolean = prefs.getBoolean("wake_enabled", false)

    fun getLatestAudioPath(): String = prefs.getString("latest_audio_path", "").orEmpty()
    fun setLatestAudioPath(path: String) {
        prefs.edit().putString("latest_audio_path", path).apply()
    }

    fun getSavedAudioCount(): Int {
        val dir = File(appContext.filesDir, "audio")
        return dir.listFiles()?.size ?: 0
    }

    fun hasVrmModel(): Boolean = File(appContext.filesDir, "annu.vrm").isFile
}
