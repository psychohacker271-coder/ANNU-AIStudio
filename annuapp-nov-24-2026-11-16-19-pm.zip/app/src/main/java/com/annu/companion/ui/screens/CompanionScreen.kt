package com.annu.companion.ui.screens

import android.webkit.WebView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.annu.companion.AnnuUiState
import com.annu.companion.ChatMessage
import com.annu.companion.ui.components.AnimatedVoiceIndicator
import com.annu.companion.ui.components.VoicePhase
import com.annu.companion.ui.theme.CrispWhite
import com.annu.companion.ui.theme.ElectricMagenta
import com.annu.companion.ui.theme.ElevatedPlum
import com.annu.companion.ui.theme.MidnightViolet
import com.annu.companion.ui.theme.MintStatus
import com.annu.companion.ui.theme.MutedLilac
import com.annu.companion.ui.theme.NeonAmethyst
import com.annu.companion.ui.theme.ObsidianBlack
import com.annu.companion.ui.theme.PlumBorder
import com.annu.companion.ui.theme.SoftLavender

@Composable
fun CompanionScreen(
    state: AnnuUiState,
    characterWebView: WebView,
    isCompactHeight: Boolean,
    onTalkTap: () -> Unit,
    onStopVoice: () -> Unit,
    onSendText: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onConfirmSensitive: () -> Unit,
    onCancelSensitive: () -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) {
            listState.animateScrollToItem(state.messages.lastIndex)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Minimal Gemini / ChatGPT-like Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "ANNU",
                    style = MaterialTheme.typography.headlineMedium,
                    color = CrispWhite
                )
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MidnightViolet,
                    border = BorderStroke(1.dp, PlumBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (state.brainConfigured) MintStatus else SoftLavender)
                        )
                        Text(
                            text = if (state.brainConfigured) "Ollama AI" else "Offline",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedLilac
                        )
                    }
                }
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("open_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = "Settings and permissions",
                    tint = SoftLavender
                )
            }
        }

        // Clean 3D Companion Stage (zero button clutter)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (isCompactHeight) 220.dp else 290.dp),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MidnightViolet),
            border = BorderStroke(1.dp, PlumBorder.copy(alpha = 0.7f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                NeonAmethyst.copy(alpha = 0.22f),
                                MidnightViolet,
                                ObsidianBlack
                            )
                        )
                    )
            ) {
                AndroidView(
                    factory = { characterWebView },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Animated Voice Indicator
        AnimatedVoiceIndicator(
            phase = state.voicePhase,
            micRms = state.micRms
        )

        // Sensitive Action Confirmation Banner (appears ONLY when needed)
        AnimatedVisibility(visible = state.pendingConfirmation != null) {
            state.pendingConfirmation?.let { pending ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B1230)),
                    border = BorderStroke(1.dp, ElectricMagenta)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Confirmation Required",
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricMagenta
                        )
                        Text(
                            text = pending.promptText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CrispWhite
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = onConfirmSensitive,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("confirm_action_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricMagenta)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(pending.confirmLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            OutlinedButton(
                                onClick = onCancelSensitive,
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("cancel_action_button"),
                                border = BorderStroke(1.dp, PlumBorder)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Cancel")
                            }
                        }
                    }
                }
            }
        }

        // Clean Conversation Feed
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.messages, key = { it.id }) { msg ->
                ChatBubble(msg)
            }
        }

        // Minimal Gemini / ChatGPT-style Input + Mic Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_text_input"),
                placeholder = {
                    Text("Ask ANNU anything…", maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                singleLine = true,
                shape = RoundedCornerShape(26.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputText.isNotBlank()) {
                            onSendText(inputText)
                            inputText = ""
                        }
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MidnightViolet,
                    unfocusedContainerColor = MidnightViolet,
                    focusedBorderColor = NeonAmethyst,
                    unfocusedBorderColor = PlumBorder,
                    focusedTextColor = CrispWhite,
                    unfocusedTextColor = CrispWhite,
                    focusedPlaceholderColor = MutedLilac,
                    unfocusedPlaceholderColor = MutedLilac
                )
            )

            if (inputText.isNotBlank()) {
                FilledIconButton(
                    onClick = {
                        onSendText(inputText)
                        inputText = ""
                    },
                    modifier = Modifier
                        .size(50.dp)
                        .testTag("send_message_button"),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = NeonAmethyst,
                        contentColor = ObsidianBlack
                    )
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send message")
                }
            }

            val isListening = state.voicePhase == VoicePhase.LISTENING
            val isSpeaking = state.voicePhase == VoicePhase.SPEAKING
            FilledIconButton(
                onClick = {
                    if (isListening || isSpeaking) onStopVoice() else onTalkTap()
                },
                modifier = Modifier
                    .size(52.dp)
                    .testTag("talk_mic_button"),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = when {
                        isListening -> ElectricMagenta
                        isSpeaking -> SoftLavender
                        else -> NeonAmethyst
                    },
                    contentColor = ObsidianBlack
                )
            ) {
                Icon(
                    imageVector = when {
                        isListening -> Icons.Default.Stop
                        isSpeaking -> Icons.Default.VolumeOff
                        else -> Icons.Default.Mic
                    },
                    contentDescription = if (isListening) "Stop listening" else "Talk to ANNU"
                )
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 310.dp),
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (message.fromUser) 18.dp else 4.dp,
                bottomEnd = if (message.fromUser) 4.dp else 18.dp
            ),
            color = if (message.fromUser) NeonAmethyst.copy(alpha = 0.24f) else ElevatedPlum,
            border = BorderStroke(
                1.dp,
                if (message.fromUser) NeonAmethyst.copy(alpha = 0.6f) else PlumBorder
            )
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (!message.fromUser && !message.sourceBadge.isNullOrBlank()) {
                    Text(
                        text = message.sourceBadge,
                        style = MaterialTheme.typography.labelSmall,
                        color = SoftLavender
                    )
                }
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = CrispWhite
                )
            }
        }
    }
}
