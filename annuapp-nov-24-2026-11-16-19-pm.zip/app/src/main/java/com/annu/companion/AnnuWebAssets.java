package com.annu.companion;

import android.content.Context;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;

public final class AnnuWebAssets {
    private static final Map<String, String> CORS_HEADERS =
            Collections.singletonMap("Access-Control-Allow-Origin", "*");

    private AnnuWebAssets() {}

    public static WebViewAssetLoader create(Context context) {
        Context appContext = context.getApplicationContext();
        WebViewAssetLoader.AssetsPathHandler defaultAssets =
                new WebViewAssetLoader.AssetsPathHandler(appContext);

        return new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", path -> {
                    if (path.endsWith(".js") || path.endsWith(".mjs")) {
                        try {
                            InputStream is = appContext.getAssets().open(path);
                            return new WebResourceResponse(
                                    "text/javascript",
                                    "utf-8",
                                    200,
                                    "OK",
                                    CORS_HEADERS,
                                    is
                            );
                        } catch (Exception e) {
                            return null;
                        }
                    }
                    if (path.endsWith(".html")) {
                        try {
                            InputStream is = appContext.getAssets().open(path);
                            return new WebResourceResponse(
                                    "text/html",
                                    "utf-8",
                                    200,
                                    "OK",
                                    CORS_HEADERS,
                                    is
                            );
                        } catch (Exception e) {
                            return null;
                        }
                    }
                    return defaultAssets.handle(path);
                })
                .addPathHandler("/model/", path -> {
                    if (!"annu.vrm".equals(path)) return null;
                    try {
                        File f = new File(appContext.getFilesDir(), "annu.vrm");
                        InputStream stream = (f.isFile() && f.length() > 1000L)
                                ? new FileInputStream(f)
                                : appContext.getAssets().open("annu.vrm");
                        return new WebResourceResponse(
                                "model/gltf-binary",
                                null,
                                200,
                                "OK",
                                CORS_HEADERS,
                                stream
                        );
                    } catch (Exception e) {
                        return null;
                    }
                })
                .build();
    }
}