package com.annu.companion;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Opt-in foreground microphone wake-phrase listener ("Hey ANNU").
 * Uses Android's SpeechRecognizer with a visible ongoing notification.
 * Screen-off hotword detection is NOT guaranteed on Android 15 / OEM devices.
 */
public class WakeWordService extends Service {
    public static final String ACTION_WAKE_STATE = "com.annu.companion.WAKE_STATE";
    public static final String EXTRA_ACTIVE = "active";
    private static final String CHANNEL = "annu_wake";

    private SpeechRecognizer recognizer;
    private Handler handler;
    private boolean stopping = false;
    private boolean triggered = false;
    private String language = "hi-IN";
    private int consecutiveErrors = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        NotificationChannel channel = new NotificationChannel(
                CHANNEL,
                "ANNU wake phrase",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Microphone is active while ANNU listens for the wake phrase");
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);

        Notification n = buildNotification("Listening for Hey ANNU. Tap Stop to turn off.");
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(43, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(43, n);
        }
        broadcastState(true);
    }

    private Notification buildNotification(String message) {
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("annu_wake", true);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 43, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, WakeWordService.class).setAction("STOP_WAKE");
        PendingIntent stopPi = PendingIntent.getService(
                this, 44, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("ANNU wake listening active")
                .setContentText(message)
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Stop listening", stopPi)
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP_WAKE".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null) {
            String lang = intent.getStringExtra("language");
            language = (lang != null && !lang.isEmpty()) ? lang : "hi-IN";
        }
        stopping = false;
        triggered = false;
        consecutiveErrors = 0;
        broadcastState(true);
        handler.removeCallbacksAndMessages(null);
        handler.post(this::beginListening);
        return START_STICKY;
    }

    private void beginListening() {
        if (stopping || triggered) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf();
            return;
        }
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) {}
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { consecutiveErrors = 0; }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rms) {}
            @Override public void onBufferReceived(byte[] b) {}
            @Override public void onEndOfSpeech() {}

            @Override
            public void onError(int error) {
                if (stopping || triggered) return;
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    stopSelf();
                    return;
                }
                consecutiveErrors++;
                long delayMs = Math.min(4000L, 900L + consecutiveErrors * 500L);
                handler.postDelayed(WakeWordService.this::beginListening, delayMs);
            }

            @Override
            public void onResults(Bundle b) {
                consecutiveErrors = 0;
                check(b);
                if (!stopping && !triggered) {
                    handler.postDelayed(WakeWordService.this::beginListening, 550);
                }
            }

            @Override
            public void onPartialResults(Bundle b) {
                check(b);
            }

            @Override public void onEvent(int event, Bundle p) {}
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        try {
            recognizer.startListening(i);
        } catch (Exception e) {
            handler.postDelayed(this::beginListening, 1500);
        }
    }

    private void check(Bundle result) {
        if (result == null || triggered) return;
        ArrayList<String> matches = result.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null) return;
        for (String phrase : matches) {
            String s = phrase.toLowerCase(Locale.ROOT)
                    .replaceAll("[^a-z\\u0900-\\u097f ]", " ")
                    .trim();
            if (s.contains("hey annu") || s.contains("hey anu")
                    || s.contains("हे अनु") || s.contains("हे अन्नू")
                    || s.equals("annu") || s.equals("अनु")) {
                triggered = true;
                try { if (recognizer != null) recognizer.cancel(); } catch (Exception ignored) {}
                NotificationManager nm = getSystemService(NotificationManager.class);
                if (nm != null) {
                    Intent open = new Intent(this, MainActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            .putExtra("annu_wake", true);
                    PendingIntent pi = PendingIntent.getActivity(
                            this, 45, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    Notification alert = new Notification.Builder(this, CHANNEL)
                            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                            .setContentTitle("ANNU heard you")
                            .setContentText("Boss, main sun rahi hoon. Tap to talk.")
                            .setContentIntent(pi)
                            .setAutoCancel(true)
                            .build();
                    try { nm.notify(45, alert); } catch (SecurityException ignored) {}
                }
                stopSelf();
                return;
            }
        }
    }

    private void broadcastState(boolean active) {
        getSharedPreferences("annu", MODE_PRIVATE).edit().putBoolean("wake_enabled", active).apply();
        Intent intent = new Intent(ACTION_WAKE_STATE).setPackage(getPackageName());
        intent.putExtra(EXTRA_ACTIVE, active);
        sendBroadcast(intent);
    }

    @Override
    public void onDestroy() {
        stopping = true;
        broadcastState(false);
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (recognizer != null) {
            try {
                recognizer.cancel();
                recognizer.destroy();
            } catch (Exception ignored) {}
            recognizer = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
