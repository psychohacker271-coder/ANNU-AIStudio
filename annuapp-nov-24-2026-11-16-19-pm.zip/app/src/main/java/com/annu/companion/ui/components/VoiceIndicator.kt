package com.annu.companion.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.annu.companion.ui.theme.ElectricMagenta
import com.annu.companion.ui.theme.ElevatedPlum
import com.annu.companion.ui.theme.MintStatus
import com.annu.companion.ui.theme.MutedLilac
import com.annu.companion.ui.theme.NeonAmethyst
import com.annu.companion.ui.theme.PlumBorder
import com.annu.companion.ui.theme.SoftLavender
import kotlin.math.PI
import kotlin.math.sin

enum class VoicePhase(val label: String) {
    IDLE("Ready • Tap mic to talk"),
    LISTENING("Listening… speak now"),
    THINKING("Thinking…"),
    SPEAKING("ANNU is speaking…")
}

@Composable
fun AnimatedVoiceIndicator(
    phase: VoicePhase,
    micRms: Float,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "voice_pulse")
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val wavePhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave"
    )

    val accentColor = when (phase) {
        VoicePhase.IDLE -> SoftLavender
        VoicePhase.LISTENING -> ElectricMagenta
        VoicePhase.THINKING -> NeonAmethyst
        VoicePhase.SPEAKING -> MintStatus
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = ElevatedPlum.copy(alpha = 0.85f),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(30.dp), contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.size(30.dp)) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val baseR = size.minDimension * 0.24f
                        val boost = when (phase) {
                            VoicePhase.IDLE -> 0.08f * pulse
                            VoicePhase.LISTENING -> 0.14f * pulse + micRms * 0.22f
                            VoicePhase.THINKING -> 0.18f * pulse
                            VoicePhase.SPEAKING -> 0.18f * pulse
                        }
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(accentColor.copy(alpha = 0.45f), Color.Transparent),
                                center = center,
                                radius = size.minDimension * (0.45f + boost)
                            ),
                            radius = size.minDimension * (0.45f + boost),
                            center = center
                        )
                        drawCircle(
                            color = accentColor,
                            radius = baseR,
                            center = center
                        )
                        drawCircle(
                            color = accentColor.copy(alpha = 0.7f),
                            radius = baseR * (1.35f + boost),
                            center = center,
                            style = Stroke(width = 2f)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = phase.label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (phase == VoicePhase.IDLE) MutedLilac else accentColor
                )
            }

            Canvas(
                modifier = Modifier
                    .width(92.dp)
                    .height(24.dp)
            ) {
                val barCount = 11
                val gap = 4.dp.toPx()
                val barW = ((size.width - gap * (barCount - 1)) / barCount).coerceAtLeast(2f)
                val maxH = size.height
                val minH = 4.dp.toPx()

                for (i in 0 until barCount) {
                    val norm = when (phase) {
                        VoicePhase.IDLE -> 0.16f + 0.08f * sin(wavePhase + i * 0.55f)
                        VoicePhase.LISTENING -> {
                            val dynamic = 0.25f + micRms * 0.75f
                            (dynamic * (0.55f + 0.45f * sin(wavePhase + i * 0.7f))).coerceIn(0.15f, 1f)
                        }
                        VoicePhase.THINKING -> 0.25f + 0.35f * ((sin(wavePhase + i * 0.6f) + 1f) / 2f)
                        VoicePhase.SPEAKING -> 0.30f + 0.65f * ((sin(wavePhase * 1.4f + i * 0.8f) + 1f) / 2f)
                    }
                    val h = (minH + (maxH - minH) * norm).coerceIn(minH, maxH)
                    val x = i * (barW + gap)
                    val y = (size.height - h) / 2f
                    drawRoundRect(
                        color = if (phase == VoicePhase.IDLE) PlumBorder else accentColor.copy(alpha = 0.9f),
                        topLeft = Offset(x, y),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                }
            }
        }
    }
}
