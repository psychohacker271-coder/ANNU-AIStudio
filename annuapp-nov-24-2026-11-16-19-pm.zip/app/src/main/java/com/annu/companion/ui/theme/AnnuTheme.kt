package com.annu.companion.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.annu.companion.R

val ObsidianBlack = Color(0xFF09070F)
val MidnightViolet = Color(0xFF130E1F)
val ElevatedPlum = Color(0xFF1D1630)
val PlumBorder = Color(0xFF332554)
val NeonAmethyst = Color(0xFFB366FF)
val SoftLavender = Color(0xFFD8B4FE)
val ElectricMagenta = Color(0xFFEC4899)
val MintStatus = Color(0xFF34D399)
val AmberStatus = Color(0xFFFBBF24)
val CrispWhite = Color(0xFFF5F3FF)
val MutedLilac = Color(0xFFA79CC8)

private val AnnuColorScheme = darkColorScheme(
    primary = NeonAmethyst,
    onPrimary = Color(0xFF1A0733),
    primaryContainer = Color(0xFF3E1F6E),
    onPrimaryContainer = CrispWhite,
    secondary = SoftLavender,
    onSecondary = Color(0xFF1E1035),
    secondaryContainer = ElevatedPlum,
    onSecondaryContainer = SoftLavender,
    tertiary = ElectricMagenta,
    onTertiary = Color(0xFF2B061A),
    background = ObsidianBlack,
    onBackground = CrispWhite,
    surface = MidnightViolet,
    onSurface = CrispWhite,
    surfaceVariant = ElevatedPlum,
    onSurfaceVariant = MutedLilac,
    outline = PlumBorder,
    outlineVariant = Color(0xFF281D42),
    error = Color(0xFFFB7185),
    onError = Color(0xFF2A0710)
)

val SpaceGroteskFont = FontFamily(
    Font(R.font.space_grotesk, FontWeight.Normal),
    Font(R.font.space_grotesk, FontWeight.Medium),
    Font(R.font.space_grotesk, FontWeight.SemiBold),
    Font(R.font.space_grotesk, FontWeight.Bold)
)

val PlusJakartaFont = FontFamily(
    Font(R.font.plus_jakarta_sans, FontWeight.Normal),
    Font(R.font.plus_jakarta_sans, FontWeight.Medium),
    Font(R.font.plus_jakarta_sans, FontWeight.SemiBold),
    Font(R.font.plus_jakarta_sans, FontWeight.Bold)
)

val AnnuTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = SpaceGroteskFont,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = SpaceGroteskFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 19.sp,
        lineHeight = 25.sp
    ),
    titleMedium = TextStyle(
        fontFamily = SpaceGroteskFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = PlusJakartaFont,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = PlusJakartaFont,
        fontWeight = FontWeight.Normal,
        fontSize = 13.5.sp,
        lineHeight = 19.sp
    ),
    labelMedium = TextStyle(
        fontFamily = PlusJakartaFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp
    ),
    labelSmall = TextStyle(
        fontFamily = PlusJakartaFont,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp
    )
)

val AnnuShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun AnnuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AnnuColorScheme,
        typography = AnnuTypography,
        shapes = AnnuShapes,
        content = content
    )
}
