package com.annu.companion

import android.Manifest
import android.app.Application
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.annu.companion.brain.AppCommandAction
import com.annu.companion.brain.CommandProcessor
import com.annu.companion.brain.CommandResult
import com.annu.companion.brain.ResponseSource
import com.annu.companion.brain.SensitiveAction
import com.annu.companion.data.AnnuMemoryRepository
import com.annu.companion.data.AnnuNote
import com.annu.companion.data.AnnuReminder
import com.annu.companion.data.SpeechLanguageMode
import com.annu.companion.ui.components.VoicePhase
import com.annu.companion.voice.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.io.FileOutputStream

data class ChatMessage(
    val id: Long,
    val fromUser: Boolean,
    val text: String,
    val sourceBadge: String? = null
)

data class PendingConfirmation(
    val promptText: String,
    val confirmLabel: String,
    val action: SensitiveAction
)

data class PermissionSnapshot(
    val micGranted: Boolean = false,
    val notificationsGranted: Boolean = true,
    val overlayGranted: Boolean = false,
    val phoneStateGranted: Boolean = false,
    val assistantHeld: Boolean = false
)

data class AnnuUiState(
    val messages: List<ChatMessage> = emptyList(),
    val voicePhase: VoicePhase = VoicePhase.IDLE,
    val micRms: Float = 0f,
    val currentAnimation: String = "idle",
    val pendingConfirmation: PendingConfirmation? = null,
    val notes: List<AnnuNote> = emptyList(),
    val reminders: List<AnnuReminder> = emptyList(),
    val languageMode: SpeechLanguageMode = SpeechLanguageMode.HINGLISH,
    val voiceLabel: String = "Initializing Indian voice…",
    val brainUrl: String = "",
    val brainModel: String = "qwen3.5:0.8b",
    val brainConfigured: Boolean = false,
    val brainTestStatus: String? = null,
    val floatingEnabled: Boolean = false,
    val wakeEnabled: Boolean = false,
    val vrmReady: Boolean = false,
    val audioCount: Int = 0,
    val isPlayingAudio: Boolean = false,
    val permissions: PermissionSnapshot = PermissionSnapshot(),
    val avatarReloadToken: Int = 0
)

class AnnuViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val memory = AnnuMemoryRepository(appContext)
    private val commandProcessor = CommandProcessor(appContext, memory)

    private val _uiState = MutableStateFlow(
        AnnuUiState(
            messages = listOf(
                ChatMessage(
                    id = 1L,
                    fromUser = false,
                    text = appContext.getString(R.string.default_greeting),
                    sourceBadge = ResponseSource.OFFLINE_ENGINE.badge
                )
            ),
            notes = memory.getNotes(),
            reminders = memory.getReminders(),
            languageMode = memory.getLanguageMode(),
            brainUrl = memory.getBrainUrl(),
            brainModel = memory.getBrainModel(),
            brainConfigured = BrainClient.configured(appContext),
            floatingEnabled = memory.isFloatingEnabled(),
            wakeEnabled = memory.isWakeEnabled(),
            vrmReady = memory.hasVrmModel(),
            audioCount = memory.getSavedAudioCount()
        )
    )
    val uiState: StateFlow<AnnuUiState> = _uiState.asStateFlow()

    var launchIntentHandler: ((Intent) -> Unit)? = null
    var webViewActionHandler: ((String) -> Unit)? = null
    var webViewSpeakHandler: ((Boolean) -> Unit)? = null
    var webViewListenHandler: ((Boolean) -> Unit)? = null
    var webViewThinkHandler: ((Boolean) -> Unit)? = null
    var fallbackSpeechPickerHandler: ((SpeechLanguageMode) -> Unit)? = null
    var commandUiActionHandler: ((AppCommandAction) -> Unit)? = null
    var requestFloatingWithPermissionHandler: (() -> Unit)? = null
    var requestWakeWithPermissionHandler: (() -> Unit)? = null

    private var importedPlayer: MediaPlayer? = null
    private var msgCounter = 2L

    private val voiceManager = VoiceManager(
        context = appContext,
        onSpeakingChanged = { speaking ->
            _uiState.update { state ->
                val nextPhase = if (speaking) VoicePhase.SPEAKING
                else if (state.voicePhase == VoicePhase.SPEAKING) VoicePhase.IDLE
                else state.voicePhase
                state.copy(voicePhase = nextPhase)
            }
            webViewSpeakHandler?.invoke(speaking)
            sendFloatingAction(if (speaking) "SPEAK_ON" else "SPEAK_OFF")
        },
        onVoiceLabelChanged = { label ->
            _uiState.update { it.copy(voiceLabel = label) }
        },
        onListeningStateChanged = { listening ->
            _uiState.update { state ->
                val nextPhase = if (listening) VoicePhase.LISTENING
                else if (state.voicePhase == VoicePhase.LISTENING) VoicePhase.IDLE
                else state.voicePhase
                state.copy(voicePhase = nextPhase)
            }
            webViewListenHandler?.invoke(listening)
        },
        onRmsChanged = { rms ->
            _uiState.update { it.copy(micRms = rms) }
        },
        onSpeechResult = { text ->
            handleUserInput(text)
        },
        onSpeechError = { errorText ->
            appendAnnuMessage(errorText, ResponseSource.OFFLINE_ENGINE.badge)
        }
    )

    private val serviceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                FloatingService.ACTION_FLOATING_STATE -> {
                    val active = intent.getBooleanExtra(FloatingService.EXTRA_ACTIVE, false)
                    _uiState.update { it.copy(floatingEnabled = active) }
                }
                WakeWordService.ACTION_WAKE_STATE -> {
                    val active = intent.getBooleanExtra(WakeWordService.EXTRA_ACTIVE, false)
                    _uiState.update { it.copy(wakeEnabled = active) }
                }
            }
        }
    }

    init {
        copyBundledVrmIfMissing()
        voiceManager.initTts(memory.getLanguageMode())
        refreshState()
        val filter = IntentFilter().apply {
            addAction(FloatingService.ACTION_FLOATING_STATE)
            addAction(WakeWordService.ACTION_WAKE_STATE)
        }
        ContextCompat.registerReceiver(
            appContext,
            serviceReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun copyBundledVrmIfMissing() {
        val target = File(appContext.filesDir, "annu.vrm")
        if (target.isFile && target.length() > 1000L) return
        try {
            appContext.assets.open("annu.vrm").use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output)
                }
            }
        } catch (_: Exception) {
        }
    }

    fun refreshState() {
        val micGranted = ContextCompat.checkSelfPermission(
            appContext, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        val notificationsGranted = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
            appContext, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        val overlayGranted = Settings.canDrawOverlays(appContext)
        val phoneStateGranted = ContextCompat.checkSelfPermission(
            appContext, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
        val assistantHeld = if (Build.VERSION.SDK_INT >= 29) {
            val rm = appContext.getSystemService(RoleManager::class.java)
            rm != null && rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)
        } else {
            false
        }

        _uiState.update {
            it.copy(
                notes = memory.getNotes(),
                reminders = memory.getReminders(),
                languageMode = memory.getLanguageMode(),
                brainUrl = memory.getBrainUrl(),
                brainModel = memory.getBrainModel(),
                brainConfigured = BrainClient.configured(appContext),
                floatingEnabled = memory.isFloatingEnabled(),
                wakeEnabled = memory.isWakeEnabled(),
                vrmReady = memory.hasVrmModel(),
                audioCount = memory.getSavedAudioCount(),
                permissions = PermissionSnapshot(
                    micGranted = micGranted,
                    notificationsGranted = notificationsGranted,
                    overlayGranted = overlayGranted,
                    phoneStateGranted = phoneStateGranted,
                    assistantHeld = assistantHeld
                )
            )
        }
    }

    fun startVoiceListening() {
        val started = voiceManager.startListening(_uiState.value.languageMode)
        if (!started) {
            fallbackSpeechPickerHandler?.invoke(_uiState.value.languageMode)
        }
    }

    fun stopVoiceListening() {
        voiceManager.stopListening()
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun handleUserInput(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        appendUserMessage(text)

        when (val result = commandProcessor.process(text)) {
            is CommandResult.Reply -> applyCommandReply(result)
            is CommandResult.NeedsConfirmation -> {
                _uiState.update {
                    it.copy(
                        pendingConfirmation = PendingConfirmation(
                            promptText = result.promptText,
                            confirmLabel = result.confirmLabel,
                            action = result.action
                        )
                    )
                }
                speakAndShow(result.promptText, ResponseSource.OFFLINE_ENGINE.badge, "think")
            }
            is CommandResult.AskAiBrain -> askBrainOrOfflineFallback(text)
        }
    }

    private fun applyCommandReply(reply: CommandResult.Reply) {
        reply.animation?.let { triggerAnimation(it) }
        reply.switchLanguage?.let { mode ->
            memory.setLanguageMode(mode)
            voiceManager.setLanguageMode(mode)
            _uiState.update { it.copy(languageMode = mode) }
        }
        when (reply.floatingAction) {
            "START" -> requestFloatingWithPermissionHandler?.invoke() ?: startFloatingCompanion()
            "STOP" -> stopFloatingCompanion()
            "SIZE_SMALL", "SIZE_LARGE", "SIZE_RESET" -> sendFloatingAction(reply.floatingAction)
        }
        when (reply.appAction) {
            AppCommandAction.START_WAKE -> requestWakeWithPermissionHandler?.invoke() ?: startWakeListening()
            AppCommandAction.STOP_WAKE -> stopWakeListening()
            AppCommandAction.PLAY_AUDIO -> playImportedAudio()
            AppCommandAction.STOP_AUDIO -> stopImportedAudio()
            AppCommandAction.REQUEST_ASSISTANT_ROLE,
            AppCommandAction.PICK_VRM,
            AppCommandAction.PICK_AUDIO,
            AppCommandAction.ENABLE_CALL_ALERTS,
            AppCommandAction.OPEN_ANNU_SETTINGS -> commandUiActionHandler?.invoke(reply.appAction)
            null -> {}
        }
        speakAndShow(reply.text, reply.source.badge, reply.animation)
        reply.launchIntent?.let { intent ->
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                launchIntentHandler?.invoke(intent)
            } catch (_: Exception) {
                speakAndShow(
                    "Boss, yeh app ya setting is device par open nahi ho paayi.",
                    ResponseSource.OFFLINE_ENGINE.badge,
                    "think"
                )
            }
        }
    }

    private fun askBrainOrOfflineFallback(userText: String) {
        if (!BrainClient.configured(appContext)) {
            val fallback = "Boss, abhi main Offline Command Engine par hoon (koi paid API key nahi chahiye). " +
                "Main apps khol sakti hoon, time/date/battery bata sakti hoon, notes & reminders save kar sakti hoon, aur 3D gestures kar sakti hoon. " +
                "Open-ended AI chat ke liye Settings mein apna free local Ollama server connect karein."
            speakAndShow(fallback, ResponseSource.OFFLINE_ENGINE.badge, "nod")
            return
        }

        _uiState.update { it.copy(voicePhase = VoicePhase.THINKING) }
        webViewThinkHandler?.invoke(true)
        val localContext = memory.buildLocalMemoryContext()

        BrainClient.ask(appContext, userText, localContext) { answer, error ->
            webViewThinkHandler?.invoke(false)
            _uiState.update { state ->
                state.copy(voicePhase = if (state.voicePhase == VoicePhase.THINKING) VoicePhase.IDLE else state.voicePhase)
            }
            if (answer != null) {
                speakAndShow(answer, ResponseSource.OLLAMA_AI.badge, "happy")
            } else {
                val safeError = error ?: "Server unreachable"
                val offlineMsg = "Boss, local Ollama AI server se connection nahi ho paaya ($safeError). " +
                    "Check karein ki PC aur phone same Wi-Fi par hain, ya offline commands use karein."
                speakAndShow(offlineMsg, ResponseSource.OFFLINE_ENGINE.badge, "think")
            }
        }
    }

    fun confirmPendingAction() {
        val pending = _uiState.value.pendingConfirmation ?: return
        _uiState.update { it.copy(pendingConfirmation = null) }
        val reply = commandProcessor.executeSensitiveAction(pending.action)
        refreshState()
        applyCommandReply(reply)
    }

    fun cancelPendingAction() {
        if (_uiState.value.pendingConfirmation == null) return
        _uiState.update { it.copy(pendingConfirmation = null) }
        speakAndShow("Theek hai Boss, woh action cancel kar diya.", ResponseSource.OFFLINE_ENGINE.badge, "nod")
    }

    fun triggerAnimation(anim: String) {
        val normalized = anim.lowercase()
        _uiState.update { it.copy(currentAnimation = normalized) }
        webViewActionHandler?.invoke(normalized)
        sendFloatingAction("ANIM_${normalized.uppercase()}")
    }

    fun addNote(content: String) {
        val clean = content.trim()
        if (clean.isEmpty()) return
        memory.addNote(clean)
        refreshState()
        speakAndShow("Ji Boss, note isi phone par save kar diya.", ResponseSource.OFFLINE_ENGINE.badge, "happy")
    }

    fun requestDeleteNote(note: AnnuNote) {
        memory.deleteNote(note.id)
        refreshState()
    }

    fun requestClearAllNotes() {
        _uiState.update {
            it.copy(
                pendingConfirmation = PendingConfirmation(
                    promptText = "Boss, kya aap sach mein saare local notes delete karna chahte hain?",
                    confirmLabel = "Delete All Notes",
                    action = SensitiveAction.DeleteAllNotes
                )
            )
        }
    }

    fun addReminder(title: String, delayMinutes: Int) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val triggerAt = System.currentTimeMillis() + delayMinutes.coerceAtLeast(1) * 60_000L
        val item = memory.addReminder(clean, triggerAt)
        ReminderReceiver.schedule(appContext, item.id, item.title, triggerAt)
        refreshState()
        speakAndShow(
            "Ji Boss, $delayMinutes minute baad ka reminder set ho gaya: \"$clean\".",
            ResponseSource.OFFLINE_ENGINE.badge,
            "happy"
        )
    }

    fun toggleReminderCompleted(reminder: AnnuReminder) {
        memory.markReminderCompleted(reminder.id, !reminder.completed)
        if (!reminder.completed) {
            ReminderReceiver.cancel(appContext, reminder.id)
        }
        refreshState()
    }

    fun deleteReminder(reminder: AnnuReminder) {
        ReminderReceiver.cancel(appContext, reminder.id)
        memory.deleteReminder(reminder.id)
        refreshState()
    }

    fun setLanguageMode(mode: SpeechLanguageMode) {
        memory.setLanguageMode(mode)
        voiceManager.setLanguageMode(mode)
        _uiState.update { it.copy(languageMode = mode) }
        val ack = when (mode) {
            SpeechLanguageMode.HINGLISH -> "Hinglish voice mode select ho gaya Boss."
            SpeechLanguageMode.HINDI -> "Hindi voice select ho gayi Boss."
            SpeechLanguageMode.ENGLISH -> "Indian English voice selected."
        }
        speakAndShow(ack, ResponseSource.OFFLINE_ENGINE.badge, "nod")
    }

    fun testFemaleVoice() {
        val line = when (_uiState.value.languageMode) {
            SpeechLanguageMode.ENGLISH -> "Hello Boss, I am ANNU, your 3D companion. My voice is ready."
            else -> "Namaste Boss! Main ANNU hoon. Meri awaaz ab bilkul ready hai."
        }
        speakAndShow(line, ResponseSource.OFFLINE_ENGINE.badge, "wave")
    }

    fun saveBrainConfig(url: String, model: String) {
        memory.saveBrainConfig(url, model)
        refreshState()
        _uiState.update {
            it.copy(
                brainTestStatus = if (url.trim().isEmpty()) "Local Ollama cleared (Offline mode active)."
                else "Saved Ollama endpoint. Tap Test to verify."
            )
        }
    }

    fun testBrainConnection(url: String, model: String) {
        memory.saveBrainConfig(url, model)
        refreshState()
        _uiState.update { it.copy(brainTestStatus = "Testing connection to LAN Ollama server…") }
        BrainClient.ask(appContext, "Reply with one short friendly sentence confirming ANNU is connected.") { answer, error ->
            if (answer != null) {
                _uiState.update { it.copy(brainTestStatus = "Connected: $answer") }
                speakAndShow("Ollama AI connected! $answer", ResponseSource.OLLAMA_AI.badge, "happy")
            } else {
                _uiState.update { it.copy(brainTestStatus = "Failed: ${error ?: "Unable to connect"}") }
            }
        }
    }

    fun clearBrainMemory() {
        BrainClient.clearConversation()
        _uiState.update { it.copy(brainTestStatus = "In-memory Ollama chat context cleared.") }
    }

    fun importVrmUri(uri: Uri) {
        try {
            val target = File(appContext.filesDir, "annu.vrm")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(target).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Cannot open selected VRM")
            refreshState()
            _uiState.update { it.copy(avatarReloadToken = it.avatarReloadToken + 1) }
            sendFloatingAction("RELOAD_MODEL")
            speakAndShow("Boss, naya VRM model save aur load ho gaya!", ResponseSource.OFFLINE_ENGINE.badge, "happy")
        } catch (_: Exception) {
            speakAndShow("Boss, VRM file import nahi ho paayi.", ResponseSource.OFFLINE_ENGINE.badge, "think")
        }
    }

    fun importAudioUri(uri: Uri) {
        try {
            val dir = File(appContext.filesDir, "audio").apply { mkdirs() }
            val mime = appContext.contentResolver.getType(uri).orEmpty()
            val ext = when {
                mime.contains("mpeg") -> ".mp3"
                mime.contains("wav") -> ".wav"
                mime.contains("mp4") -> ".m4a"
                mime.contains("ogg") -> ".ogg"
                mime.contains("aac") -> ".aac"
                else -> ".audio"
            }
            val saved = File(dir, "audio_${System.currentTimeMillis()}$ext")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(saved).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Cannot open audio")
            memory.setLatestAudioPath(saved.absolutePath)
            refreshState()
            speakAndShow("Boss, audio sample save ho gaya. Memory tab se play kar sakte hain.", ResponseSource.OFFLINE_ENGINE.badge, "nod")
        } catch (_: Exception) {
            speakAndShow("Boss, audio file import nahi ho paayi.", ResponseSource.OFFLINE_ENGINE.badge, "think")
        }
    }

    fun playImportedAudio() {
        val path = memory.getLatestAudioPath()
        if (path.isEmpty() || !File(path).isFile) {
            speakAndShow("Boss, pehle koi audio sample import kijiye.", ResponseSource.OFFLINE_ENGINE.badge, "think")
            return
        }
        try {
            stopImportedAudio()
            importedPlayer = MediaPlayer().apply {
                setDataSource(path)
                setOnPreparedListener { mp ->
                    mp.start()
                    _uiState.update { it.copy(isPlayingAudio = true) }
                }
                setOnCompletionListener { mp ->
                    mp.release()
                    if (importedPlayer === mp) importedPlayer = null
                    _uiState.update { it.copy(isPlayingAudio = false) }
                }
                setOnErrorListener { mp, _, _ ->
                    mp.release()
                    if (importedPlayer === mp) importedPlayer = null
                    _uiState.update { it.copy(isPlayingAudio = false) }
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            _uiState.update { it.copy(isPlayingAudio = false) }
        }
    }

    fun stopImportedAudio() {
        importedPlayer?.let { mp ->
            try { mp.stop() } catch (_: Exception) {}
            try { mp.release() } catch (_: Exception) {}
        }
        importedPlayer = null
        _uiState.update { it.copy(isPlayingAudio = false) }
    }

    fun startFloatingCompanion() {
        if (!Settings.canDrawOverlays(appContext)) return
        memory.setFloatingEnabled(true)
        val service = Intent(appContext, FloatingService::class.java)
        appContext.startForegroundService(service)
        refreshState()
    }

    fun stopFloatingCompanion() {
        memory.setFloatingEnabled(false)
        appContext.stopService(Intent(appContext, FloatingService::class.java))
        refreshState()
    }

    fun sendFloatingAction(action: String) {
        if (!memory.isFloatingEnabled()) return
        try {
            appContext.startService(Intent(appContext, FloatingService::class.java).setAction(action))
        } catch (_: Exception) {
        }
    }

    fun startWakeListening() {
        val intent = Intent(appContext, WakeWordService::class.java)
            .putExtra("language", _uiState.value.languageMode.ttsLocaleTag)
        appContext.startForegroundService(intent)
        refreshState()
        speakAndShow(
            "Boss, Hey ANNU wake listening start ho gayi hai. Ongoing notification se kabhi bhi band kar sakte hain.",
            ResponseSource.OFFLINE_ENGINE.badge,
            "nod"
        )
    }

    fun stopWakeListening() {
        appContext.stopService(Intent(appContext, WakeWordService::class.java))
        refreshState()
        speakAndShow("Boss, wake listening band kar di gayi hai.", ResponseSource.OFFLINE_ENGINE.badge, "nod")
    }

    fun handleSystemTrigger(intent: Intent?) {
        if (intent == null) return
        if (intent.getBooleanExtra("annu_incoming_call", false)) {
            intent.removeExtra("annu_incoming_call")
            speakAndShow(
                "Boss, aapko incoming call aa rahi hai. Android privacy rules ke karan main call audio nahi sun sakti; aap phone par baat kar sakte hain.",
                ResponseSource.OFFLINE_ENGINE.badge,
                "wave"
            )
        }
        if (intent.getBooleanExtra("annu_wake", false)) {
            intent.removeExtra("annu_wake")
            speakAndShow("Ji Boss, main sun rahi hoon!", ResponseSource.OFFLINE_ENGINE.badge, "listening")
            startVoiceListening()
        }
        if (intent.getBooleanExtra("annu_voice_assist", false)) {
            intent.removeExtra("annu_voice_assist")
            speakAndShow("Ji Boss, ANNU sun rahi hai!", ResponseSource.OFFLINE_ENGINE.badge, "listening")
            startVoiceListening()
        }
        val reminderTitle = intent.getStringExtra("annu_reminder_title")
        if (!reminderTitle.isNullOrBlank()) {
            intent.removeExtra("annu_reminder_title")
            speakAndShow("Boss, aapka reminder hai: $reminderTitle", ResponseSource.OFFLINE_ENGINE.badge, "happy")
        }
    }

    private fun speakAndShow(text: String, sourceBadge: String, anim: String?) {
        anim?.let { triggerAnimation(it) }
        appendAnnuMessage(text, sourceBadge)
        voiceManager.speak(text)
    }

    private fun appendUserMessage(text: String) {
        val msg = ChatMessage(id = msgCounter++, fromUser = true, text = text)
        _uiState.update { it.copy(messages = (it.messages + msg).takeLast(30)) }
    }

    private fun appendAnnuMessage(text: String, badge: String) {
        val msg = ChatMessage(id = msgCounter++, fromUser = false, text = text, sourceBadge = badge)
        _uiState.update { it.copy(messages = (it.messages + msg).takeLast(30)) }
    }

    override fun onCleared() {
        try { appContext.unregisterReceiver(serviceReceiver) } catch (_: Exception) {}
        stopImportedAudio()
        voiceManager.shutdown()
        super.onCleared()
    }
}
