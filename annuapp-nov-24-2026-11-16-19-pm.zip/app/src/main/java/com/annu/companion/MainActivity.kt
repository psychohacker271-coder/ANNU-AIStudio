package com.annu.companion

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowHeightSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.annu.companion.brain.AppCommandAction
import com.annu.companion.ui.screens.CompanionScreen
import com.annu.companion.ui.screens.SettingsScreen
import com.annu.companion.ui.theme.AnnuTheme
import com.annu.companion.ui.theme.ObsidianBlack

class MainActivity : ComponentActivity() {
    private val viewModel: AnnuViewModel by viewModels()
    private lateinit var characterWebView: WebView
    private var pendingAfterMic: (() -> Unit)? = null
    private var pendingAfterNotification: (() -> Unit)? = null
    private var openSettingsRequested by mutableStateOf(false)

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshState()
        if (granted) {
            pendingAfterMic?.invoke()
        }
        pendingAfterMic = null
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshState()
        if (granted) {
            pendingAfterNotification?.invoke()
        }
        pendingAfterNotification = null
    }

    private val phonePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshState()
    }

    private val overlaySettingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshState()
        if (Settings.canDrawOverlays(this)) {
            ensureNotificationThen { viewModel.startFloatingCompanion() }
        }
    }

    private val assistantRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshState()
    }

    private val speechIntentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val matches = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.firstOrNull()?.trim().orEmpty()
            if (text.isNotEmpty()) {
                viewModel.handleUserInput(text)
            }
        }
    }

    private val vrmPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importVrmUri(uri)
        }
    }

    private val audioPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importAudioUri(uri)
        }
    }

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)

        // Initialize ViewModel (copies bundled VRM if missing) before loading WebView
        viewModel.refreshState()
        characterWebView = createCharacterWebView()
        bindViewModelHandlers()

        setContent {
            AnnuTheme {
                val windowSize = calculateWindowSizeClass(this)
                val compactHeight = windowSize.heightSizeClass == WindowHeightSizeClass.Compact
                val state by viewModel.uiState.collectAsStateWithLifecycle()
                var showSettings by rememberSaveable { mutableStateOf(false) }

                LaunchedEffect(openSettingsRequested) {
                    if (openSettingsRequested) {
                        showSettings = true
                        openSettingsRequested = false
                    }
                }

                BackHandler(enabled = showSettings) {
                    showSettings = false
                }

                LaunchedEffect(state.avatarReloadToken) {
                    if (state.avatarReloadToken > 0) {
                        characterWebView.reload()
                    }
                }

                LaunchedEffect(showSettings) {
                    characterWebView.evaluateJavascript(
                        "if(window.annuSetPaused)window.annuSetPaused($showSettings)",
                        null
                    )
                }

                Scaffold(
                    containerColor = ObsidianBlack,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(ObsidianBlack)
                    ) {
                        Crossfade(targetState = showSettings, label = "screen_switch") { settingsVisible ->
                            if (!settingsVisible) {
                                CompanionScreen(
                                    state = state,
                                    characterWebView = characterWebView,
                                    isCompactHeight = compactHeight,
                                    onTalkTap = {
                                        ensureMicThen { viewModel.startVoiceListening() }
                                    },
                                    onStopVoice = {
                                        viewModel.stopVoiceListening()
                                        viewModel.stopSpeaking()
                                    },
                                    onSendText = { viewModel.handleUserInput(it) },
                                    onOpenSettings = { showSettings = true },
                                    onConfirmSensitive = { viewModel.confirmPendingAction() },
                                    onCancelSensitive = { viewModel.cancelPendingAction() }
                                )
                            } else {
                                SettingsScreen(
                                    state = state,
                                    onBack = { showSettings = false },
                                    onSelectLanguage = { viewModel.setLanguageMode(it) },
                                    onTestVoice = { viewModel.testFemaleVoice() },
                                    onSaveBrain = { url, model -> viewModel.saveBrainConfig(url, model) },
                                    onTestBrain = { url, model -> viewModel.testBrainConnection(url, model) },
                                    onClearBrainContext = { viewModel.clearBrainMemory() },
                                    onRequestAssistantRole = { requestAssistantRole() },
                                    onOpenVoiceInputSettings = { openVoiceInputSettings() },
                                    onRequestMicPermission = {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    },
                                    onRequestNotificationPermission = {
                                        if (Build.VERSION.SDK_INT >= 33) {
                                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                    },
                                    onRequestOverlayPermission = { openOverlayPermissionScreen() },
                                    onRequestPhonePermission = {
                                        phonePermissionLauncher.launch(Manifest.permission.READ_PHONE_STATE)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        viewModel.handleSystemTrigger(intent)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createCharacterWebView(): WebView {
        val assetLoader = AnnuWebAssets.create(this)
        return WebView(this).apply {
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(AndroidColor.TRANSPARENT)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage): Boolean {
                    android.util.Log.d(
                        "ANNU_WEB",
                        "${consoleMessage.messageLevel()}: ${consoleMessage.message()} (${consoleMessage.lineNumber()})"
                    )
                    return true
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }
            }
            loadUrl("https://appassets.androidplatform.net/assets/annu.html")
        }
    }

    private fun bindViewModelHandlers() {
        viewModel.launchIntentHandler = { intent ->
            startActivity(intent)
        }
        viewModel.webViewActionHandler = { anim ->
            characterWebView.evaluateJavascript("if(window.annuAction)window.annuAction('$anim')", null)
        }
        viewModel.webViewSpeakHandler = { speaking ->
            characterWebView.evaluateJavascript("if(window.annuSpeak)window.annuSpeak($speaking)", null)
        }
        viewModel.webViewListenHandler = { listening ->
            characterWebView.evaluateJavascript("if(window.annuListen)window.annuListen($listening)", null)
        }
        viewModel.webViewThinkHandler = { thinking ->
            characterWebView.evaluateJavascript("if(window.annuThink)window.annuThink($thinking)", null)
        }
        viewModel.fallbackSpeechPickerHandler = { mode ->
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, mode.ttsLocaleTag)
                putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.listening_prompt))
            }
            try {
                speechIntentLauncher.launch(i)
            } catch (_: Exception) {
            }
        }
        viewModel.requestFloatingWithPermissionHandler = {
            toggleFloatingWithPermissions()
        }
        viewModel.requestWakeWithPermissionHandler = {
            ensureMicThen {
                ensureNotificationThen {
                    viewModel.startWakeListening()
                }
            }
        }
        viewModel.commandUiActionHandler = { action ->
            when (action) {
                AppCommandAction.REQUEST_ASSISTANT_ROLE -> requestAssistantRole()
                AppCommandAction.PICK_VRM -> vrmPickerLauncher.launch(arrayOf("model/gltf-binary", "application/octet-stream", "*/*"))
                AppCommandAction.PICK_AUDIO -> audioPickerLauncher.launch(arrayOf("audio/*"))
                AppCommandAction.ENABLE_CALL_ALERTS -> phonePermissionLauncher.launch(Manifest.permission.READ_PHONE_STATE)
                AppCommandAction.OPEN_ANNU_SETTINGS -> openSettingsRequested = true
                AppCommandAction.START_WAKE,
                AppCommandAction.STOP_WAKE,
                AppCommandAction.PLAY_AUDIO,
                AppCommandAction.STOP_AUDIO -> {}
            }
        }
    }

    private fun ensureMicThen(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingAfterMic = action
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun ensureNotificationThen(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        ) {
            action()
        } else {
            pendingAfterNotification = action
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun toggleFloatingWithPermissions() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermissionScreen()
            return
        }
        ensureNotificationThen {
            viewModel.startFloatingCompanion()
        }
    }

    private fun openOverlayPermissionScreen() {
        overlaySettingsLauncher.launch(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun requestAssistantRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                if (!rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)) {
                    assistantRoleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT))
                }
                return
            }
        }
        openVoiceInputSettings()
    }

    private fun openVoiceInputSettings() {
        try {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        viewModel.handleSystemTrigger(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshState()
        characterWebView.evaluateJavascript("if(window.annuSetPaused)window.annuSetPaused(false)", null)
        if (viewModel.uiState.value.floatingEnabled) {
            viewModel.sendFloatingAction("HIDE")
        }
    }

    override fun onPause() {
        characterWebView.evaluateJavascript("if(window.annuSetPaused)window.annuSetPaused(true)", null)
        if (viewModel.uiState.value.floatingEnabled) {
            viewModel.sendFloatingAction("SHOW")
        }
        super.onPause()
    }

    override fun onDestroy() {
        characterWebView.destroy()
        super.onDestroy()
    }
}
