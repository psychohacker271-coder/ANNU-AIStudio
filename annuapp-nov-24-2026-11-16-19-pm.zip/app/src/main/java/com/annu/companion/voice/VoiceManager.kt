package com.annu.companion.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.annu.companion.data.SpeechLanguageMode
import java.util.Locale

class VoiceManager(
    context: Context,
    private val onSpeakingChanged: (Boolean) -> Unit,
    private val onVoiceLabelChanged: (String) -> Unit,
    private val onListeningStateChanged: (Boolean) -> Unit,
    private val onRmsChanged: (Float) -> Unit,
    private val onSpeechResult: (String) -> Unit,
    private val onSpeechError: (String) -> Unit
) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var currentMode: SpeechLanguageMode = SpeechLanguageMode.HINGLISH

    fun initTts(initialMode: SpeechLanguageMode) {
        currentMode = initialMode
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                configureTtsVoice(currentMode)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        mainHandler.post { onSpeakingChanged(true) }
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post { onSpeakingChanged(false) }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post { onSpeakingChanged(false) }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        mainHandler.post { onSpeakingChanged(false) }
                    }
                })
            } else {
                mainHandler.post { onVoiceLabelChanged("TTS unavailable on device") }
            }
        }
    }

    fun setLanguageMode(mode: SpeechLanguageMode) {
        currentMode = mode
        if (ttsReady) {
            configureTtsVoice(mode)
        }
    }

    private fun configureTtsVoice(mode: SpeechLanguageMode) {
        val engine = tts ?: return
        val targetLocale = if (mode == SpeechLanguageMode.ENGLISH) {
            Locale("en", "IN")
        } else {
            Locale("hi", "IN")
        }
        engine.language = targetLocale
        engine.setSpeechRate(0.95f)
        engine.setPitch(1.08f)

        val selected = pickFemaleIndianVoice(engine, targetLocale)
        if (selected != null) {
            engine.voice = selected
            val quality = if (selected.isNetworkConnectionRequired) "Online" else "Offline"
            mainHandler.post {
                onVoiceLabelChanged("${selected.locale.displayLanguage} (${selected.locale.country}) • $quality • ${selected.name}")
            }
        } else {
            mainHandler.post {
                onVoiceLabelChanged("${targetLocale.displayLanguage} (${targetLocale.country}) • System Default")
            }
        }
    }

    private fun pickFemaleIndianVoice(engine: TextToSpeech, targetLocale: Locale): Voice? {
        val voices = try {
            engine.voices ?: emptySet()
        } catch (_: Exception) {
            emptySet()
        }
        if (voices.isEmpty()) return null

        val preferredHints = listOf(
            "hia", "hie", "hid", "ena", "enc", "end",
            "female", "woman", "aditi", "raveena", "lekha", "kalpana", "sangeeta"
        )
        val localeMatches = voices.filter { v ->
            v.locale.language.equals(targetLocale.language, ignoreCase = true) &&
                v.locale.country.equals("IN", ignoreCase = true)
        }
        val candidates = localeMatches.ifEmpty {
            voices.filter { it.locale.language.equals(targetLocale.language, ignoreCase = true) }
        }
        if (candidates.isEmpty()) return null

        return candidates
            .sortedWith(
                compareByDescending<Voice> { voice ->
                    val name = voice.name.lowercase(Locale.ROOT)
                    preferredHints.any { hint -> name.contains(hint) }
                }.thenBy { it.isNetworkConnectionRequired }
                    .thenByDescending { it.quality }
            )
            .firstOrNull()
    }

    fun speak(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        if (!ttsReady) return
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "annu_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        onSpeakingChanged(false)
    }

    fun startListening(mode: SpeechLanguageMode): Boolean {
        currentMode = mode
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            return false
        }
        stopSpeaking()
        stopListening()

        val recognizer = SpeechRecognizer.createSpeechRecognizer(appContext)
        speechRecognizer = recognizer
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                mainHandler.post { onListeningStateChanged(true) }
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                mainHandler.post { onRmsChanged(normalized) }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                mainHandler.post {
                    onRmsChanged(0f)
                    onListeningStateChanged(false)
                }
            }

            override fun onError(error: Int) {
                mainHandler.post {
                    onRmsChanged(0f)
                    onListeningStateChanged(false)
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "Awaz clear nahi suni. Dobara boliye Boss."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch sunai nahi diya. Mic tap karke phir boliye."
                        SpeechRecognizer.ERROR_AUDIO -> "Microphone audio error."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Speech network error. Internet ya offline speech pack check karein."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "Microphone permission zaroori hai."
                        else -> "Voice recognition error ($error)."
                    }
                    onSpeechError(msg)
                }
            }

            override fun onResults(results: Bundle?) {
                mainHandler.post {
                    onRmsChanged(0f)
                    onListeningStateChanged(false)
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.trim().orEmpty()
                    if (text.isNotEmpty()) {
                        onSpeechResult(text)
                    } else {
                        onSpeechError("Awaz samajh nahi aayi. Dobara try karein.")
                    }
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, mode.ttsLocaleTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, mode.ttsLocaleTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        return try {
            recognizer.startListening(intent)
            true
        } catch (_: Exception) {
            onListeningStateChanged(false)
            false
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        onRmsChanged(0f)
        onListeningStateChanged(false)
    }

    fun shutdown() {
        stopListening()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
    }
}
