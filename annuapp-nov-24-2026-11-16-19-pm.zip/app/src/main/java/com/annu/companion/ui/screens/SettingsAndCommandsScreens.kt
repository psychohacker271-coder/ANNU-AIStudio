package com.annu.companion.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assistant
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.annu.companion.AnnuUiState
import com.annu.companion.data.SpeechLanguageMode
import com.annu.companion.ui.theme.AmberStatus
import com.annu.companion.ui.theme.CrispWhite
import com.annu.companion.ui.theme.ElevatedPlum
import com.annu.companion.ui.theme.MidnightViolet
import com.annu.companion.ui.theme.MintStatus
import com.annu.companion.ui.theme.MutedLilac
import com.annu.companion.ui.theme.NeonAmethyst
import com.annu.companion.ui.theme.ObsidianBlack
import com.annu.companion.ui.theme.PlumBorder
import com.annu.companion.ui.theme.SoftLavender

@Composable
fun SettingsScreen(
    state: AnnuUiState,
    onBack: () -> Unit,
    onSelectLanguage: (SpeechLanguageMode) -> Unit,
    onTestVoice: () -> Unit,
    onSaveBrain: (String, String) -> Unit,
    onTestBrain: (String, String) -> Unit,
    onClearBrainContext: () -> Unit,
    onRequestAssistantRole: () -> Unit,
    onOpenVoiceInputSettings: () -> Unit,
    onRequestMicPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestPhonePermission: () -> Unit
) {
    var brainUrlInput by remember(state.brainUrl) { mutableStateOf(state.brainUrl) }
    var brainModelInput by remember(state.brainModel) { mutableStateOf(state.brainModel) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("settings_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to ANNU",
                    tint = CrispWhite
                )
            }
            Spacer(Modifier.width(4.dp))
            Text("ANNU Settings", style = MaterialTheme.typography.titleLarge, color = CrispWhite)
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Voice & Language
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MidnightViolet),
                    border = BorderStroke(1.dp, PlumBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = NeonAmethyst)
                            Text("Voice & Language", style = MaterialTheme.typography.titleMedium, color = SoftLavender)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SpeechLanguageMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = state.languageMode == mode,
                                    onClick = { onSelectLanguage(mode) },
                                    label = { Text(mode.label, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                        Text("Active Voice: ${state.voiceLabel}", style = MaterialTheme.typography.bodyMedium, color = MutedLilac)
                        OutlinedButton(
                            onClick = onTestVoice,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("test_voice_button"),
                            border = BorderStroke(1.dp, NeonAmethyst)
                        ) {
                            Text("Test Indian Voice")
                        }
                    }
                }
            }

            // Free Local AI (Ollama)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MidnightViolet),
                    border = BorderStroke(1.dp, PlumBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Psychology, contentDescription = null, tint = NeonAmethyst)
                            Text("Free Local AI (Ollama LAN PC)", style = MaterialTheme.typography.titleMedium, color = SoftLavender)
                        }
                        Text(
                            "No paid API key needed. Connect Ollama on your PC over Wi-Fi, or use ANNU's offline command engine anytime.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedLilac
                        )
                        OutlinedTextField(
                            value = brainUrlInput,
                            onValueChange = { brainUrlInput = it },
                            modifier = Modifier.fillMaxWidth().testTag("ollama_url_input"),
                            label = { Text("Ollama LAN URL") },
                            placeholder = { Text("http://192.168.1.10:11434") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonAmethyst,
                                unfocusedBorderColor = PlumBorder,
                                focusedTextColor = CrispWhite,
                                unfocusedTextColor = CrispWhite
                            )
                        )
                        OutlinedTextField(
                            value = brainModelInput,
                            onValueChange = { brainModelInput = it },
                            modifier = Modifier.fillMaxWidth().testTag("ollama_model_input"),
                            label = { Text("Ollama Model") },
                            placeholder = { Text("qwen3.5:0.8b") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonAmethyst,
                                unfocusedBorderColor = PlumBorder,
                                focusedTextColor = CrispWhite,
                                unfocusedTextColor = CrispWhite
                            )
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { onSaveBrain(brainUrlInput, brainModelInput) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("ollama_save_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = NeonAmethyst, contentColor = ObsidianBlack)
                            ) {
                                Text("Save")
                            }
                            OutlinedButton(
                                onClick = { onTestBrain(brainUrlInput, brainModelInput) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("ollama_test_button"),
                                border = BorderStroke(1.dp, NeonAmethyst)
                            ) {
                                Text("Test AI")
                            }
                        }
                        OutlinedButton(
                            onClick = onClearBrainContext,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            border = BorderStroke(1.dp, PlumBorder)
                        ) {
                            Text("Clear Chat Memory Context")
                        }
                        state.brainTestStatus?.let { status ->
                            Text(status, style = MaterialTheme.typography.bodyMedium, color = SoftLavender)
                        }
                    }
                }
            }

            // Default Assistant & Limitations
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MidnightViolet),
                    border = BorderStroke(1.dp, PlumBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Assistant, contentDescription = null, tint = NeonAmethyst)
                            Text("Android Voice Assistant", style = MaterialTheme.typography.titleMedium, color = SoftLavender)
                        }
                        Button(
                            onClick = onRequestAssistantRole,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("assistant_role_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (state.permissions.assistantHeld) ElevatedPlum else NeonAmethyst,
                                contentColor = if (state.permissions.assistantHeld) MintStatus else ObsidianBlack
                            )
                        ) {
                            Text(
                                if (state.permissions.assistantHeld) "ANNU is Default Assistant"
                                else "Set ANNU as Default Assistant"
                            )
                        }
                        OutlinedButton(
                            onClick = onOpenVoiceInputSettings,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            border = BorderStroke(1.dp, PlumBorder)
                        ) {
                            Text("System Digital Assistant Settings")
                        }
                        Surface(
                            color = ObsidianBlack.copy(alpha = 0.6f),
                            shape = MaterialTheme.shapes.small,
                            border = BorderStroke(1.dp, AmberStatus.copy(alpha = 0.4f))
                        ) {
                            Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = AmberStatus, modifier = Modifier.size(18.dp))
                                Text(
                                    "Voice-Controlled Features: Say \"Hey ANNU wake listening on/off\", \"Float on/off\", \"Change VRM\", or \"Import audio\" directly to ANNU. Android 15 does not guarantee screen-off hotword wake; wake listening uses a visible microphone service.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MutedLilac
                                )
                            }
                        }
                    }
                }
            }

            // Permissions & Privacy
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MidnightViolet),
                    border = BorderStroke(1.dp, PlumBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NeonAmethyst)
                            Text("Permissions & Privacy", style = MaterialTheme.typography.titleMedium, color = SoftLavender)
                        }
                        PermissionRow("Microphone (Voice & Wake)", state.permissions.micGranted, onRequestMicPermission)
                        PermissionRow("Notifications (Reminders & Alerts)", state.permissions.notificationsGranted, onRequestNotificationPermission)
                        PermissionRow("Display Over Other Apps (Floating 3D)", state.permissions.overlayGranted, onRequestOverlayPermission)
                        PermissionRow("Phone State (Incoming Call Alert)", state.permissions.phoneStateGranted, onRequestPhonePermission)

                        Text(
                            "Call & Data Privacy: Incoming-call alert only shows a notification when ringing; ANNU cannot access call audio or speak on calls. Notes and reminders stay on-device. Stored notes: ${state.notes.size} • Reminders: ${state.reminders.size}.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedLilac
                        )
                    }
                }
            }

            // Voice Commands Quick Guide
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MidnightViolet),
                    border = BorderStroke(1.dp, PlumBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("What You Can Say to ANNU", style = MaterialTheme.typography.titleMedium, color = SoftLavender)
                        Text(
                            "• Apps & System: \"Open Camera\", \"Open YouTube\", \"Wi-Fi settings\", \"Bluetooth settings\"\n" +
                                "• Info: \"Time batao\", \"Aaj ki tarikh\", \"Battery status\"\n" +
                                "• Memory: \"Remember that...\", \"Mera note batao\", \"Remind me in 10 minutes to...\"\n" +
                                "• Floating & Wake: \"Float on\", \"Chota ho ja\", \"Stop floating\", \"Wake listening on/off\"\n" +
                                "• 3D & Media: \"Dance\", \"Wave\", \"Sit\", \"Sleep\", \"Change VRM\", \"Play audio\"\n" +
                                "• Sensitive (Asks confirmation): \"Call 1234567890\", \"Send message\", \"Delete all notes\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedLilac
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionRow(label: String, granted: Boolean, onGrant: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = if (granted) Icons.Default.CheckCircle else Icons.Default.WarningAmber,
                contentDescription = null,
                tint = if (granted) MintStatus else AmberStatus,
                modifier = Modifier.size(18.dp)
            )
            Text(label, style = MaterialTheme.typography.bodyMedium, color = CrispWhite)
        }
        if (!granted) {
            OutlinedButton(
                onClick = onGrant,
                modifier = Modifier.heightIn(min = 48.dp),
                border = BorderStroke(1.dp, NeonAmethyst)
            ) {
                Text("Allow")
            }
        } else {
            Text("Granted", style = MaterialTheme.typography.labelMedium, color = MintStatus)
        }
    }
}
