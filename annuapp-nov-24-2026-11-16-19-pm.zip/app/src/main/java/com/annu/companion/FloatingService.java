package com.annu.companion;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import java.util.Locale;

public class FloatingService extends Service {
    public static final String ACTION_FLOATING_STATE = "com.annu.companion.FLOATING_STATE";
    public static final String EXTRA_ACTIVE = "active";
    private static final String CHANNEL = "annu_companion";

    private SharedPreferences prefs;
    private WindowManager wm;
    private WebView avatar;
    private WindowManager.LayoutParams params;
    private WebViewAssetLoader assets;
    private int visibleWidth = 180;
    private int visibleHeight = 220;
    private String pendingAnimation = "idle";
    private boolean speaking = false;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("annu", MODE_PRIVATE);
        NotificationChannel c = new NotificationChannel(CHANNEL, "ANNU companion", NotificationManager.IMPORTANCE_LOW);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(c);
        startForeground(41, notification());
        if (Settings.canDrawOverlays(this)) {
            showAvatar();
            broadcastFloatingState(true);
        } else {
            broadcastFloatingState(false);
            stopSelf();
        }
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, FloatingService.class).setAction("STOP");
        PendingIntent sp = PendingIntent.getService(
                this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ANNU is floating")
                .setContentText("3D companion is on screen")
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Stop", sp)
                .build();
    }

    private void showAvatar() {
        assets = AnnuWebAssets.create(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        avatar = new WebView(this);
        WebSettings s = avatar.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        avatar.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return assets.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript("if(window.annuAction)window.annuAction('" + pendingAnimation + "')", null);
                v.evaluateJavascript("if(window.annuSpeak)window.annuSpeak(" + speaking + ")", null);
            }
        });
        avatar.setWebChromeClient(new WebChromeClient());
        avatar.setBackgroundColor(0);
        avatar.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        visibleWidth = prefs.getInt("avatar_width", 180);
        visibleHeight = prefs.getInt("avatar_height", 220);
        params = new WindowManager.LayoutParams(
                visibleWidth,
                visibleHeight,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = prefs.getInt("avatar_x", 12);
        params.y = prefs.getInt("avatar_y", 180);

        avatar.setOnTouchListener(new View.OnTouchListener() {
            int x, y;
            float sx, sy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    x = params.x;
                    y = params.y;
                    sx = e.getRawX();
                    sy = e.getRawY();
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = x + (int) (e.getRawX() - sx);
                    params.y = y + (int) (e.getRawY() - sy);
                    try { wm.updateViewLayout(avatar, params); } catch (Exception ignored) {}
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (Math.abs(e.getRawX() - sx) < 12 && Math.abs(e.getRawY() - sy) < 12) {
                        Intent i = new Intent(FloatingService.this, MainActivity.class)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(i);
                    } else {
                        prefs.edit().putInt("avatar_x", params.x).putInt("avatar_y", params.y).apply();
                    }
                    return true;
                }
                return true;
            }
        });
        wm.addView(avatar, params);
        avatar.loadUrl("https://appassets.androidplatform.net/assets/annu.html?floating=1");
    }

    private void resizeAvatar(int w, int h) {
        if (params == null || avatar == null) return;
        visibleWidth = w;
        visibleHeight = h;
        params.width = w;
        params.height = h;
        try {
            wm.updateViewLayout(avatar, params);
            prefs.edit().putInt("avatar_width", w).putInt("avatar_height", h).apply();
        } catch (Exception ignored) {}
    }

    private void visible(boolean v) {
        if (avatar == null || params == null) return;
        try {
            params.width = v ? visibleWidth : 0;
            params.height = v ? visibleHeight : 0;
            wm.updateViewLayout(avatar, params);
            avatar.evaluateJavascript("if(window.annuSetPaused)window.annuSetPaused(" + (!v) + ")", null);
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        if (i != null) {
            String act = i.getAction();
            if ("STOP".equals(act)) {
                broadcastFloatingState(false);
                stopSelf();
                return START_NOT_STICKY;
            }
            if ("HIDE".equals(act)) visible(false);
            if ("SHOW".equals(act)) visible(true);
            if ("SIZE_SMALL".equals(act)) resizeAvatar(140, 175);
            if ("SIZE_NORMAL".equals(act)) resizeAvatar(180, 220);
            if ("SIZE_LARGE".equals(act)) resizeAvatar(220, 270);
            if ("SIZE_RESET".equals(act)) {
                if (params != null) {
                    params.x = 12;
                    params.y = 180;
                }
                prefs.edit().putInt("avatar_x", 12).putInt("avatar_y", 180).apply();
                resizeAvatar(180, 220);
            }
            if ("RELOAD_MODEL".equals(act) && avatar != null) {
                avatar.reload();
            }
            if (act != null && act.startsWith("ANIM_")) {
                pendingAnimation = act.substring(5).toLowerCase(Locale.ROOT);
                if (avatar != null) {
                    avatar.evaluateJavascript("if(window.annuAction)window.annuAction('" + pendingAnimation + "')", null);
                }
            }
            if ("SPEAK_ON".equals(act) || "SPEAK_OFF".equals(act)) {
                speaking = "SPEAK_ON".equals(act);
                if (avatar != null) {
                    avatar.evaluateJavascript("if(window.annuSpeak)window.annuSpeak(" + speaking + ")", null);
                }
            }
        }
        return START_STICKY;
    }

    private void broadcastFloatingState(boolean active) {
        if (prefs != null) {
            prefs.edit().putBoolean("floating_enabled", active).apply();
        }
        Intent intent = new Intent(ACTION_FLOATING_STATE).setPackage(getPackageName());
        intent.putExtra(EXTRA_ACTIVE, active);
        sendBroadcast(intent);
    }

    @Override
    public void onDestroy() {
        broadcastFloatingState(false);
        if (wm != null && avatar != null) {
            try { wm.removeView(avatar); } catch (Exception ignored) {}
        }
        if (avatar != null) avatar.destroy();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }
}