# ANNU — Android 3D AI Companion (`com.annu.companion`)

ANNU is a voice-first Android 3D anime companion built with Kotlin, Jetpack Compose (Material 3 dark purple & obsidian theme), Android `VoiceInteractionService`, and an offline-capable WebGL/Three.js VRM renderer.

## Build Instructions

1. Ensure JDK 17+ and Android SDK 35 are installed (or use AI Studio / GitHub Actions).
2. The `prepareAnnuAssets` Gradle task automatically copies `4728432443254068622_v001.vrm` to `app/src/main/assets/annu.vrm` and downloads the Three.js (`0.180.0`) and `@pixiv/three-vrm` (`v3`) modules into `app/src/main/assets/vendor/`.
3. Build debug APK:
   ```bash
   gradle :app:assembleDebug
   ```
   Output: `app/build/outputs/apk/debug/app-debug.apk`
4. Build unsigned release APK (sign with your release keystore before Play/device distribution):
   ```bash
   gradle :app:assembleRelease
   ```
   Output: `app/build/outputs/apk/release/app-release-unsigned.apk`
5. Run local JVM / Robolectric unit tests:
   ```bash
   gradle :app:testDebugUnitTest
   ```

## Implemented Features

- **Minimal Assistant UI**: Gemini/ChatGPT-style single-screen dark purple & obsidian interface with a 3D companion stage, animated voice waveform indicator, conversation transcript, and a single Settings button.
- **Voice-First Controls**: Almost every capability can be triggered directly by speaking or typing in Hindi, English, or Hinglish—no button clutter.
- **Female Indian TTS & Speech**: Automatically selects an available `hi-IN` / `en-IN` female voice on the device TTS engine with Hinglish, Hindi, and English modes.
- **3D VRM Companion**: Uses your supplied VRM (`4728432443254068622_v001.vrm`) with smooth pose interpolation (`idle`, `listening`, `thinking`, `speaking`, `happy`, `wave`, `dance`, `walk`, `sit`, `nod`, `sleep`, `wake`), natural double-blinking, and pause-on-hide optimization for 4 GB RAM devices (e.g., Realme C53).
- **Android Assistant & Wake Phrase**: Implements `VoiceInteractionService` / `VoiceInteractionSessionService`, `RoleManager.ROLE_ASSISTANT` setup, and opt-in foreground `WakeWordService` (`"Hey ANNU"`).
- **AI Brain + Honest Offline Engine**: Optional free local Ollama (`/api/chat`) over LAN Wi-Fi with no paid API keys, paired with an offline command engine that never pretends rule-based replies are generative AI.
- **Device Commands & Confirmation Safety**: Opens installed apps, Settings, Wi-Fi, Bluetooth, Camera, Maps, Alarms; reports time, date, and battery status; manages local notes & scheduled reminders (`AlarmManager` + notifications); and asks explicit confirmation before deleting data, dialing calls (`ACTION_DIAL`), or opening SMS (`ACTION_SENDTO`).
- **Floating 3D Overlay & Call Alert**: Draggable floating VRM overlay (`FloatingService`) and legal incoming-call notification alert (`CallAlertReceiver`).

## Permissions & Honest Limitations

- `RECORD_AUDIO` / `FOREGROUND_SERVICE_MICROPHONE`: Used for voice input and opt-in `"Hey ANNU"` wake listening. **Limitation**: Android 15 does not guarantee screen-off hotword wake for third-party apps; `WakeWordService` runs with an ongoing notification and uses Android's `SpeechRecognizer`.
- `POST_NOTIFICATIONS`: Used for local reminders, foreground service status, wake alerts, and incoming-call alerts.
- `SYSTEM_ALERT_WINDOW` / `FOREGROUND_SERVICE_SPECIAL_USE`: Used only if you enable the floating 3D overlay.
- `READ_PHONE_STATE`: Used only to show an incoming-call alert notification when ringing. **Limitation**: Android 15 does not allow third-party apps to read cellular call audio or autonomously talk to callers, and this app deliberately avoids restricted `READ_CALL_LOG` / `CALL_PHONE` / `SEND_SMS` permissions.
- **Ollama LAN AI**: Requires your PC on the same Wi-Fi running Ollama (`OLLAMA_HOST=0.0.0.0`). Without it, ANNU runs in offline command mode.

## First-Time Setup on Realme C53 (Android 15)

1. Install the APK (`app-debug.apk` or signed release APK) and open **ANNU**.
2. Tap the **Mic** button and grant Microphone permission to talk immediately.
3. Tap the top-right **Settings** icon to:
   - Test/select **Hinglish**, **Hindi**, or **English** voice.
   - Set **ANNU as Default Android Assistant**.
   - Optionally enter your PC's **Ollama LAN URL** (e.g., `http://192.168.1.10:11434`).
   - Grant optional **Notifications**, **Overlay**, or **Phone State** permissions as needed.
